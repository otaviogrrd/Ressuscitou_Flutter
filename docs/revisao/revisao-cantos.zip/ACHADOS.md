# Achados por ficha

### 000 — A cabana dos pastores

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-cabana-dos-pastores.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b9bd981fd55f63a7-pair.jpg)

- letra: Palavras foram fundidas: «beijes com» virou «beijescom»; «beijos de sua» virou «beijosdesua». Há outras junções na primeira estrofe.
- alinhamento: Espaçamento e quebras das estrofes diferem da ficha; o rascunho preserva BIS como texto solto e não é uma versão estendida pronta.
- chordNotes: Cifras Re-, Sib e La estão visíveis nas duas imagens; não foi observada nesta leitura uma mudança de altura que dispense nova conferência de alinhamento.

### 001 — A ceifa das nações

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ceifa-das-nacoes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/76b832998edba523-pair.jpg)

- letra: Há perda de acento («VÓS»→«VOS») e junção de palavras («Pois bem»→«Poisbem»). A segunda coluna também contém junções.
- alinhamento: O rascunho contém pontos e parênteses espúrios entre cifras e o primeiro refrão; linhas e grandes espaços deslocam verticalmente as entradas.
- chordNotes: As raízes das cifras aparentes foram preservadas, mas as linhas espúrias impedem aceitar a associação visual de todas as cifras às entradas.

### 002 — A cordeira de Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-cordeira-de-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3c60ef9073dc12b6-pair.jpg)

- letra: Na estrofe de Raquel, a palavra «que» saiu da sequência e aparece em uma linha isolada após a continuação da frase; várias palavras são fundidas.
- alignment: A cifra Si7 anterior ao primeiro ROGAI fica isolada muito acima da linha cantada; a referência bíblica também foi reconhecida com números/pontuação incorretos.
- chordNotes: Mi-, La-, Do e Si7 aparecem, mas a correspondência vertical de Si7 com a linha de entrada está comprometida.

### 003 — A Espada

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-espada.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f867d4cd01dc3e0d-pair.jpg)

- cifra: Diversas cifras Mi7 foram reconhecidas como «Mi?» na segunda coluna; a qualidade/extensão deixa de ser uma cifra válida.
- letra: Palavras foram fundidas, por exemplo «polida para»→«polidapara». O desenho do acorde no rodapé não foi preservado; seu OCR gerou caracteres soltos.
- chordNotes: O asterisco de Mi7* e a alternativa Sol#dim7 exigem revisão específica; o diagrama não é representado corretamente pelo texto OCR.

### 004 — A marcha é dura

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-marcha-e-dura.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0cb0f83ed4e13062-pair.jpg)

- cifra: No segundo verso do refrão, Mi- da ficha aparece como Mi (sem o menor) no rascunho, nas duas ocorrências.
- letra: «é dura» virou «édura» e «forte o» virou «forteo»; partes do cabeçalho vermelho foram convertidas indevidamente em La/Mi.
- chordNotes: A perda do sinal menor muda a qualidade harmônica e impede aprovação.

### 005 — A ninguém demos ocasião de tropeço

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ninguem-demos-ocasiao-de-tropeco.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ab6caa146c432c42-pair.jpg)

- letra: A linha «A NINGUÉM DEMOS OCASIÃO DE TROPEÇO» do primeiro refrão está ausente do corpo; restaram cifras/pontos em área vazia.
- alignment: As cifras do refrão ficam afastadas das linhas cantadas por grandes vazios. As duas colunas contêm outras palavras coladas.
- chordNotes: A omissão da linha torna impossível aceitar a associação das cifras do primeiro refrão com a letra.

### 006 — A ti levanto meus olhos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ti-levanto-meus-olhos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/947b9e67c2f4a162-pair.jpg)

- letra: A primeira estrofe contém junções extensas: «olhos dos»→«olhosdos» e palavras seguintes estão coladas; o refrão também começa com ATI em vez de A TI.
- alinhamento: O BIS A. ficou como BISA. isolado entre linhas, sem representar a repetição por extenso necessária à versão estendida.
- chordNotes: Re-, Sol-, Sib7 e La7 continuam visíveis; não houve validação exaustiva de cada posição após corrigir as palavras.

### 007 — A Ti, Senhor, com minha voz gritando imploro

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ti-senhor-com-minha-voz-gritando-imploro.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2ac82e40227b2542-pair.jpg)

- letra: «mais fortes do» aparece fundido como «maisfortesdo»; há várias outras junções nos dois painéis de letra.
- alignment: Pontos e grandes intervalos de linhas foram introduzidos entre partes da estrofe e acordes; a grade precisa ser refeita após separar a letra.
- chordNotes: As cifras aparentes La-, Re-, Mi/Mi7, Fa e Sol preservam a grafia básica, sem certificação integral das posições.

### 008 — A Ti, Senhor levanto minha alma

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ti-senhor-levanto-minha-alma.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/395e6439331c3b85-pair.jpg)

- letra: «teu caminho» virou «teucaminho» e «tua ternura» virou «tuaternura»; outras junções afetam a leitura das estrofes.
- cifra: A sequência de dois acordes Re- Fa aparece colada como Re-Fa em várias linhas. É necessário restabelecer a separação e os pontos de entrada.
- chordNotes: Não se trata de conversão A–G: são dois acordes da própria ficha que ficaram visualmente unidos.

### 009 — A Ti, Senhor, se deve o louvor em Sião

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ti-senhor-se-deve-o-louvor-em-siao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ddbc1396a4bc5b02-pair.jpg)

- letra: «se cumpre» aparece em «tisecumpre» e há várias junções, inclusive nas linhas da segunda coluna. A pontuação e os espaços precisam de recomposição.
- alinhamento: O primeiro refrão ganhou pontos/intervalos entre as cifras e a linha cantada; a separação vertical não acompanha a ficha.
- chordNotes: Re-, Sol-, Sib e La7 aparecem nas duas evidências, sem alteração de altura claramente observada nesta leitura.

### 010 — À vítima pascal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-vitima-pascal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/efc4b472188701ef-pair.jpg)

- cifra: A cifra La7 do começo aparece como La? no rascunho. Isso não é notação equivalente e deixa a extensão indefinida.
- letra: Palavras estão coladas em ambas as colunas; os diagramas de Re-9 e Fa maj7 do rodapé viraram traços/caracteres, não desenhos utilizáveis.
- chordNotes: Além de corrigir La?, é preciso revisar a qualidade/extensão e a representação dos dois diagramas, sem perder a legenda harmônica.

### 011 — A voz do meu amado

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-voz-do-meu-amado.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fcef486b375ef3c3-pair.jpg)

- letra: Há perda de acento em «Ó»→«O» e junções como «meu amado»→«meuamado». A estrofe da pomba contém pontuação solta acima da entrada.
- alinhamento: As marcas BIS permanecem isoladas, e a transcrição apresenta vários vazios entre cifras e letra. Não está pronta como versão estendida.
- chordNotes: La-, Sol, Re-, Mi, Fa e Do aparentes estão preservados; a revisão exaustiva de alinhamento permanece necessária após corrigir as palavras.

### 012 — Abba, Pai

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/abba-pai.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a0c3ffd5ec02f885-pair.jpg)

- letra: A linha «para recairmos no temor» foi colada em uma única sequência de texto, repetida nas duas ocorrências.
- cifra: No começo e no final, Fa e Do ficaram colados como FaDo, prejudicando a separação dos dois acordes.
- chordNotes: As alturas de Sol/Fa/Do são reconhecíveis, mas a junção FaDo precisa ser corrigida antes de conferir a transposição e o alinhamento.

### 013 — Abraão

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/abraao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d58982d1455fed6c-pair.jpg)

- letra: «eis três» foi deformado em «istrês» na primeira coluna; há muitas outras junções, inclusive na fala e nas respostas.
- alinhamento: A grade contém grandes vazios entre fragmentos de estrofes e acordes. A reconstrução exige separar palavras sem deslocar as entradas.
- chordNotes: La-, Re-, Mi, Fa e Sol aparentes continuam nas duas imagens; não foi certificada a posição de cada cifra.

### 014 — Aclamai o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aclamai-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d11b1be576305a69-pair.jpg)

- letra: Há junções como «Entrai em»→«Entraiem» e «sua presença»→«suapresença», com outros casos nas estrofes.
- alinhamento: BIS A. virou BISA. em texto solto, e há pontos soltos perto dos retornos. As marcas de melisma precisam permanecer associadas às linhas corretas.
- chordNotes: As cifras principais e a sequência Sol-, Re-, La, Re- estão aparentes; não há aprovação de alinhamento após corrigir as junções.

### 015 — Akedá

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/akeda.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/38357dcfb7a5a543-pair.jpg)

- letra: A abertura contém junções como «Era ainda»→«Eraainda» e «noite quando»→«noitequando»; outras junções seguem nas duas colunas.
- alinhamento: Parênteses e caracteres espúrios aparecem nas chamadas; o diagrama de Re-9 foi reduzido a texto/traços, e BIS permanece abreviado.
- chordNotes: A cifra Re-9 em si aparece equivalente; o desenho de posição não foi conservado.

### 016 — Alçai ó portas

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/alcai-o-portas.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a5ac786ccbe9c159-pair.jpg)

- letra: Perde-se acentuação em respostas, por exemplo «É»→«E», e há muitas palavras coladas nas estrofes e perguntas.
- alignment: Várias cifras ficam acima de linhas vazias/pontuação isolada, especialmente nas respostas; o vínculo visual com a letra precisa ser reconstruído.
- chordNotes: Mi/Mi-, Si/Si-, Sol e La estão aparentes; não foi marcada como erro a alternância maior/menor que também existe na ficha.

### 017 — Alegria, Nasceu O Salvador

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/alegria-nasceu-o-salvador.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/383543d0a8c3b483-pair.jpg)

- letra: «será o» foi fundido como «serão» no verso do sinal, alterando a leitura. Há outras junções na narrativa.
- alinhamento: O diagrama de Reb virou caracteres soltos no rodapé. As muitas marcações BIS não são uma expansão estendida conferida.
- chordNotes: Reb e Do7 estão presentes no refrão, mas o diagrama de digitação não foi representado.

### 018 — Aleluia! Bendizei o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aleluia-bendizei-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b21acf225ad92869-pair.jpg)

- letra: Na primeira linha das crianças, a sílaba IA foi reduzida a A e U ficou unido a LU. Há junções como «Bendizei o Senhor»→«BendizeioSenhor».
- alinhamento: As sílabas do aleluia e do melisma precisam de nova separação; a marca BIS A. e a indicação de braçadeira foram fragmentadas.
- chordNotes: La, Sib, Re- e La7 permanecem aparentes. A perda de sílaba exige refazer a associação das cifras ao canto.

### 019 — Aleluia! Já chegou o reino

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aleluia-ja-chegou-o-reino.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/497aaaa8ad0caa43-pair.jpg)

- letra: Há junções como «seu Cristo»→«seuCristo» e «convidados às»→«convidadosàs», nas duas colunas.
- chordNotes: Do, Mi e La- aparentam manter alturas/qualidades. Este rascunho ainda exige separação integral das palavras e conferência final de posições.

### 020 — Aleluia! Louvai o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aleluia-louvai-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0d3cf57273e8bb9e-pair.jpg)

- letra: «louvai-o no alto firmamento» foi unido numa sequência; «címbalos sonoros» virou «cimbalossonoros», perdendo acento e espaço.
- cifra: Na abertura, pares como La Mi e Re Mi aparecem colados como LaMi e ReMi; são acordes distintos que precisam de separação visual.
- chordNotes: As raízes ainda são reconhecíveis, mas não se deve importar os pares fundidos como se fossem uma única cifra.

### 021 — Amo o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/amo-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0d6ab4eca0bea24f-pair.jpg)

- cifra: La7 virou La? nas duas linhas PRESERVOU e na segunda coluna. O diagrama de Mi-6 também desapareceu, restando sua legenda.
- letra: «Alçarei» foi reconhecido como «Algarei» e várias palavras estão fundidas nas estrofes.
- chordNotes: Fa#- e Mi-6 aparentes foram mantidos; os La? não podem substituir uma extensão definida na ficha.

### 022 — Ao despertar

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ao-despertar.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6db2565eb3321cc9-pair.jpg)

- cifra: Na estrofe superior da segunda coluna, o Fa# da ficha aparece como Faé. O acidente deixou de ser reconhecido como sustenido.
- letra: Na primeira coluna, «ouvido» perdeu a vogal inicial e aparece unido à palavra anterior. Outras junções estão presentes nos dois lados.
- chordNotes: Outros Fa# continuam legíveis, portanto o problema não é uma conversão intencional de notação; deve ser corrigido ocorrência a ocorrência.

### 023 — As armas da luz

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/as-armas-da-luz.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2ba0d250254a3b6b-pair.jpg)

- cifra: No início da segunda coluna, Mi7 foi reconhecido como Mi?. A cifra fica inválida/indefinida.
- letra: «Cristo te ama» virou «Cristoteama», com várias outras junções; o diagrama de Re-9 do rodapé tornou-se caracteres espúrios.
- chordNotes: A extensão 7 precisa ser reposta onde virou interrogação, sem aprovar apenas pela presença de outras cifras Mi7 corretas.

### 024 — Assim fala o amém

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/assim-fala-o-amem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d00f374b749c7e6e-pair.jpg)

- letra: Na primeira frase da segunda coluna, a ordem «que me» foi quebrada: me ficou na linha superior e que foi para a inferior, mudando a sequência de leitura.
- letra: Também há muitas palavras coladas nas duas colunas e quebras artificiais em frases contínuas.
- chordNotes: Mi-, Do, Re7, Si7 e Sol aparentes estão presentes; a ordem da letra deve ser corrigida antes da conferência final dos acordes.

### 025 — Até quando?

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ate-quando.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4a3abc9947ba0f04-pair.jpg)

- letra: «rosto ocultarás» virou «rostoocultarás» e «confio em» virou «confioem», entre outras junções.
- alinhamento: A disposição do texto e os vazios entre linhas divergem da ficha; os retornos abreviados continuam pendentes de expansão estendida.
- chordNotes: Mi e La- aparentes mantêm a qualidade. A revisão precisa recompor palavras sem mudar os locais de entrada das cifras.

### 026 — Ave Maria I

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ave-maria-i.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ca70174f9c7e8c24-pair.jpg)

- letra: «sois vós» virou «soisvós» e «entre todas» virou «entretodas»; a primeira parte contém outras junções.
- cifra: Mi e La- aparecem fundidos como MiLa- em mais de uma chamada, dificultando a leitura de dois acordes sucessivos.
- chordNotes: As alturas/qualidades desses dois acordes são reconhecíveis; o erro registrado é a falta de separação, não uma mudança de notação.

### 027 — Ave Maria II (1984)

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ave-maria-ii-1984.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3205cd134aab2011-pair.jpg)

- letra: «bendita sois vós» virou «benditasoisvós» e «entre todas as» virou «entretodasas». Há mais junções na primeira parte.
- chordNotes: A sequência Do/Mi/Fa da ficha foi preservada como tal; não foi tratada como erro por conter barras. Mi/Fa das linhas finais também estão aparentes.

### 028 — Babilônia criminal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/babilonia-criminal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7d5b9f170f2762b0-pair.jpg)

- letra: Há junções como «cantar um»→«cantarum» e perda de acento em «ATÉ»→«ATE», além de outras na segunda coluna.
- alinhamento: Pontos e vazios foram introduzidos entre acordes e frases, sobretudo antes da resposta sobre arrasar e no retorno final.
- chordNotes: Mi-, La-, Re e Si7 aparentes não mostram conversão de altura claramente errada; a disposição precisa ser refeita após corrigir a letra.

### 029 — Balaão

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/balaao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1b3c20d5ce4bde5e-pair.jpg)

- letra: «fez vir» virou «fezvir» e «rocha eu» virou «rochaeu», entre outras junções nas duas colunas.
- alinhamento: A resposta final recebeu parêntese e pontos soltos antes de JACÓ; as marcas de repetição perderam a barra e ainda precisam de expansão editorial.
- chordNotes: As cifras com baixo/sequência Sol/Si- devem ser preservadas conforme cada ocorrência da ficha; não foi encontrada diferença de altura certificável nesta leitura.

### 030 — Bendirei o Senhor em todo tempo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bendirei-o-senhor-em-todo-tempo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/00b6b1ace7b71023-pair.jpg)

- letra: «Cantai comigo» virou «Cantaicomigo»; no refrão da segunda coluna, E e VEDE ficaram unidos, além de outras junções.
- alinhamento: BIS A. aparece como BISA. solto. A indicação de repetição não delimita um trecho estendido pronto para uso.
- chordNotes: Re-, Do, Sib, La e La7 aparentes foram conservados; a separação das palavras continua bloqueando a aprovação.

### 031 — Bendita és tu, Maria

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bendita-es-tu-maria.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/394b7468c321c284-pair.jpg)

- letra: «Bendita és» virou «Benditaés» e «tu acreditaste» virou «tuacreditaste», entre outros casos de palavras unidas.
- alinhamento: BIS permanece em texto solto nos dois refrões; a revisão de repetições por extenso não foi realizada neste rascunho normal.
- chordNotes: La-, Sol, Fa, Mi e Re- estão aparentes. Não foi observada mudança de altura nas cifras destacadas, sem certificação integral das posições.

### 032 — Bendito seja Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bendito-seja-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/163c01f6b2ca48a2-pair.jpg)

- cifra: Fa# aparece deformado como Faf no começo da segunda coluna e na entrada de NELE TAMBÉM. O acidente precisa ser reconhecido corretamente.
- letra: «da criação» virou «dacriação» e «Nele também» virou «Neletambém», com várias junções adicionais.
- chordNotes: Há também acordes Mi- e La7 visualmente unidos; corrigir separação sem mudar a qualidade menor de Mi.

### 033 — Bendito sejas, Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bendito-sejas-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a37f4ecdc32aa641-pair.jpg)

- letra: «A TI GLÓRIA» foi unido como «ATIGLÓRIA» em refrões; «seja o» também aparece como «sejao».
- chordNotes: Sol, Fa#-, Mi, Mi-, Re, Do e Si7 aparentes conservam as raízes/qualidades, mas as palavras e seu espaçamento exigem correção integral.

### 034 — Bendize, minha alma, a Iahweh

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bendize-minha-alma-a-lahweh.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0310ee362d7966f4-pair.jpg)

- letra: Falta a terceira linha do refrão inicial, que repete BENDIZE antes de NÃO ESQUEÇAS. A cifra Mi permanece em uma linha vazia no lugar do texto.
- letra: As estrofes contêm palavras unidas em longas sequências, prejudicando leitura e correspondência com as cifras.
- chordNotes: A cifra Mi da linha omitida não basta para preservar a entrada; é necessário restaurar a linha inteira com seu alinhamento.

### 035 — Benedictus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/benedictus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a60ec791abee95ea-pair.jpg)

- cifra: No final da primeira coluna, La7 foi reconhecido como La?. Isso deixa a extensão do acorde indefinida.
- letra: «nos liberta dos» foi unido como «noslibertados», e há muitas outras junções ao longo das duas colunas.
- chordNotes: A maioria das demais ocorrências de La7 está legível; a correção precisa alcançar também esta ocorrência final, não só a cifra no cabeçalho.

### 036 — Canta a Iahweh, Jerusalém

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/canta-a-iahweh-jerusalem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6b11743b236cc477-pair.jpg)

- cifra: Várias ocorrências de La7 da ficha aparecem como La? no refrão e nas estrofes de ambas as colunas.
- letra: «pôs» foi deformado como «pds», e há diversas palavras fundidas nas duas colunas.
- chordNotes: As extensões 7 não podem ficar como interrogação; é necessário conferir cada ocorrência, inclusive as recorrentes.

### 037 — Cantai A Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/cantai-a-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f4af73ba84a56c61-pair.jpg)

- letra: Foi omitida a segunda ocorrência inicial de CANTAI A DEUS, que deveria ficar entre TOCAI e APLAINAI no bloco de abertura.
- letra: Há várias palavras fundidas, e o diagrama de Re-9 do rodapé virou caracteres sem representação de digitação.
- chordNotes: Mi e Re-9 aparentes permanecem; a linha omitida e o limite da repetição precisam ser restaurados antes de revisar entradas.

### 038 — Cântico de Ana

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/cantico-de-ana.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/8d1f0985f1d1653f-pair.jpg)

- letra: Na estrofe da morte/vida, a preposição ao foi deslocada para depois de Xeol e para outra linha, mudando a ordem do verso.
- letra: Há perda de acentos nas respostas (HÁ vira HA), palavras unidas e pontuação solta em retornos.
- chordNotes: As cifras Sol/La-, Mi/La-, Re-/La- e Fa/Mi continuam aparentes, mas o deslocamento de palavras invalida a associação visual final.

### 039 — Cântico dos três jovens

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/cantico-dos-tres-jovens.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ad74988333363204-pair.jpg)

- letra: Na litania, e saiu da linha VENTOS/BRISAS e ficou abaixo; em GELOS/NEVES, a resposta BENDIZEI aparece antes da conclusão do objeto. A ordem de leitura foi alterada.
- letra: Há várias palavras unidas nas invocações e no recitado final, além de respostas/reticências deslocadas.
- chordNotes: Mi7 e La- das respostas continuam aparentes, mas a litania e seus limites de repetição precisam de reconstrução integral.

### 040 — Canto de Moisés

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/canto-de-moises.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/820738d03888fda9-pair.jpg)

- letra: A frase dos carros do Faraó foi quebrada em linhas que intercalam os termos fora da ordem original. Também o que da abertura aparece depois da continuação da frase.
- alignment: O rascunho mistura fragmentos de frases com vazios e caracteres espúrios; a associação das cifras à letra deixa de ser utilizável.
- chordNotes: Do7, Fa, La7, Re7 e Sol7 são reconhecíveis, mas a presença dessas cifras não valida as entradas diante da letra embaralhada.

### 041 — Caritas Christi urget nos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/caritas-christi-urget-nos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e8568fcf16b83f4f-pair.jpg)

- letra: «Cristo nos compele» foi fundido em «Cristonoscompele»; há outras junções na narrativa e nas respostas.
- alinhamento: O melisma é mantido como anotação solta e as linhas possuem vazios grandes; conferir o vínculo da indicação com a frase após recompor os espaços.
- chordNotes: Mi-, Sol, Si, La-, Do, Re e La-9 aparentes foram preservados, sem aprovação exaustiva dos pontos de entrada.

### 042 — Carmen 63

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/carmen-63.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/974cea7e31053ff0-pair.jpg)

- letra: Fusões em 'Estãorotasminhas', 'minhas portasdepar' e 'jáestáforjada'.
- alinhamento: Cifras da resposta ESTÃO ROTAS / PAGAS ficam separadas da letra por vazios excessivos.
- repeticao: Retorno final GANHAREI MEU REINO permanece abreviado com reticências.

### 043 — Chegue à tua presença meu clamor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/chegue-a-tua-presenca-meu-clamor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b76a8d3f88293baf-pair.jpg)

- letra: Omitida a linha 'Chegue à tua presença meu clamor,' após La-.
- letra: Fusões 'brotede', 'canteminha' e 'línguatuas'.
- alinhamento: La- fica órfão antes de Fa da linha seguinte.
- repeticao: Retornos finais ficam com reticências, sem expansão.

### 044 — Como a corça

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-a-corca.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fe369afb46585498-pair.jpg)

- letra: Fusões 'corçaanseiapelascorrentesde', 'teabates,almaminha'.
- cifra: Primeira resposta direita: Sol no HTML em lugar de Sol# sobre o segundo DEUS; na resposta inicial esquerda Faf- em vez de Fa#-.
- repeticao: Retornos finais ESPERA EM DEUS e Porque ele permanecem abreviados.

### 045 — Como condenados a morte

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-condenados-a-morte.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1836bc6569831f47-pair.jpg)

- letra: Fusões 'anós', 'Postoscomo' e 'paraos'.
- alinhamento: Na resposta direita La- aparece sem letra; das quatro linhas COMO CONDENADOS À MORTE só três são legíveis no HTML.
- repeticao: Omitida uma das quatro repetições explícitas de COMO CONDENADOS À MORTE; retornos finais abreviados.

### 046 — Como é maravilhoso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-e-maravilhoso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/8842b47073c98bb1-pair.jpg)

- letra: Fusões 'émaravilhoso', 'Écomo', 'pelabarba', 'aVidapara'.
- cifra: Re7 virou Re? no primeiro Maravilhoso e em Nos deu; resposta MARAVILHOSO perdeu menor de Si- (SolSi).
- alinhamento: Linha É como óleo que desce quebra que em linha avulsa.
- repeticao: Refrão final fica com reticências.

### 047 — Como ovelha que vê

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-ovelha-que-ve.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5599b9145bb5be21-pair.jpg)

- letra: Fusões 'Mariaseguia-o', 'ver-tenesteestado' e 'MeuFilhoe'.
- alinhamento: Cifras de diversas linhas ficam isoladas por grande espaço vertical (Nunca poderia imaginar / que chegaria).
- repeticao: Retorno COMO OVELHA QUE VÊ continua abreviado com reticências até DA TUA VIDA.

### 048 — Como são amáveis tuas moradas

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-sao-amaveis-tuas-moradas.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1e299cfc16385892-pair.jpg)

- letra: Fusões 'amáveistuas', 'pelosátriosdo', 'Valemaisum dianosteusátrios'.
- letra: A SANTA VIAGEM final aparece como 'ÀSANTA VIAGEM'.
- alinhamento: Parêntese avulso antes de NOS PALÁCIOS DOS POTENTES; cifras de refrão afastadas da letra.
- repeticao: Retornos PASSANDO e FELIZ QUEM HABITA permanecem com reticências.

### 049 — Confessei a ti o meu pecado

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/confessei-a-ti-o-meu-pecado.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f5bce2af4a4c1cb7-pair.jpg)

- letra: Fusões 'TIO', 'ETU', 'cujoespíritonão', 'porelaaridezdo' e 'te indicareiocaminho'.
- alinhamento: Cifras Re-/La- em Feliz o homem ficam muito separadas verticalmente de suas linhas.
- repeticao: Todos os retornos CONFESSEI A TI O MEU PECADO continuam abreviados.

### 050 — Consolai o meu povo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/consolai-o-meu-povo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ed6703f7ca4e06a4-pair.jpg)

- letra: Fusões 'EFALAI', 'EGRITAI-LHE', 'vozno desertogrita' e 'opastorleva'.
- repeticao: Retorno CONSOLAI final fica abreviado.

### 051 — Cristo É A Luz

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/cristo-e-a-luz.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e65be429c22504f1-pair.jpg)

- letra: Fusões recorrentes 'Cristoé', 'aVida', 'aVerdade', 'ÉO' e 'ÉA' nas respostas.

### 052 — Dayenu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/dayenu-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e9a98c64e32f3046-pair.jpg)

- letra: Fusões 'Cristonos tivessefeitosairdo', 'tivesselibertadodetodos', 'tivesseconstruídoem'.
- alinhamento: Cifras da segunda exposição De quantos bens ficam isoladas da letra por vão vertical.
- repeticao: Respostas ISTO NOS TERIA BASTADO ficam abreviadas em todas as estrofes seguintes.

### 053 — Dayenu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/dayenu-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b2314df149860cfd-pair.jpg)

- letra: Fusões 'fezsairdo', 'fezentrarna', 'estáressuscitado'; primeira frase Tanto mais nós temos que dar graças ao Senhor quebra em fragmentos fora de ordem linear.
- alinhamento: Primeira linha divide que/graças ao abaixo de temos/dar/Senhor; Que nos deu as suas riquezas fragmentada em duas alturas.
- repeticao: BIS A. aparece como texto/barra em todas as estrofes sem expandir a resposta por extenso.

### 054 — De profundis

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/de-profundis.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e6f236bcfb04082a-pair.jpg)

- letra: Fusões 'TIGRITO', 'tensem', 'nossospecados', 'TISE', 'Eleredime'.
- cifra: Fa7 das duas primeiras frases vira Fa?.
- repeticao: BIS A./BISA/BIS preservados como indicações sem repetição por extenso.

### 055 — Dia de repouso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/dia-de-repouso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4cb9543565ef619c-pair.jpg)

- achadosLetra: ‘Abraão viu este dia’ virou ‘Abraão viueste dia’; várias palavras coladas (‘Coroa desalvação’, ‘EDE’).
- achadosCifras: La-/Mi- perdem menor: início mostra ‘la’ e ‘Mi’; MEMORIAL também la/Mi sem hífen.
- achadosAlinhamento: Cifras do refrão e respostas deslocadas; marcador BIS vira linha isolada.
- achadosRepeticoes: Bloco duplo do refrão presente, mas BIS sem abrangência visual.

### 056 — Diante dos anjos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/diante-dos-anjos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6852549feca77cd7-pair.jpg)

- achadosLetra: Muitas junções: ‘que olhaparao humilde’, ‘todoo coração’, ‘Dar-te-ãograças’. Diagrama final convertido em ruído ‘ec./Rad’.
- achadosCifras: Re-9 e principais alturas visíveis preservados; diagrama do acorde não preservado.
- achadosAlinhamento: Espaçamento entre cifra e verso muda muito nas estrofes; diagrama ausente.
- achadosRepeticoes: Chamadas DIANTE DOS ANJOS mantidas com reticências separadas.

### 057 — Diz o Senhor ao meu Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/diz-o-senhor-ao-meu-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9841ee345597b874-pair.jpg)

- achadosLetra: Junções (‘teupoder’, ‘teusinimigos’, ‘porissolevantaacabeça’); ‘Tu és sacerdote’ sem espaços.
- achadosCifras: Do#-, Sol#, Si7 visualmente presentes nas estrofes; sem erro de altura óbvio na visão geral.
- achadosAlinhamento: Cifras afastadas verticalmente do verso e palavras aglutinadas prejudicam ancoragem.
- achadosRepeticoes: Repetições e chamadas finais presentes; reticências deslocadas.

### 058 — Dizei aos de coração cansado

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/dizei-aos-de-coracao-cansado.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3cb590eb29f35811-pair.jpg)

- achadosLetra: ‘Dizei aos’→‘Dizeiaos’; ‘e se abrirão os ouvidos’→‘e seabrirãoos ouvidosdos’; diagrama vira ec./Rad.
- achadosCifras: Re-9, La-, Mi- presentes; diagrama Re-9 perdido.
- achadosAlinhamento: Grandes lacunas cifra/linha no refrão e estrofes.
- achadosRepeticoes: Quatro linhas Aleluia e duas E CANTARÃO presentes.

### 059 — É paciente

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/e-paciente.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/171255fee6329efa-pair.jpg)

- achadosLetra: ‘nossa vida tudo’→‘vidatudo’; ‘e nos ensina a ser pacientes’→‘e nos ensinaa serpacientes’; título residual ‘Mi PACIENTE’.
- achadosCifras: Título/resíduo textual classificado como cifra vermelha (‘Mi PACIENTE’), conteúdo que não é acorde.
- achadosAlinhamento: Grandes intervalos verticais; cifra perde proximidade ao texto.
- achadosRepeticoes: Refrão e chamadas presentes; negrito assembleia e separação perdidos.

### 060 — Eis-me aqui que venho em breve

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eis-me-aqui-que-venho-em-breve.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0a33fbfe8edef7af-pair.jpg)

- achadosLetra: ‘a raiz da’→‘araizda’, ‘dar a cada’→‘daracada’, ‘o Alfa e o Ômega’→‘oAlfae oÔmega’.
- achadosCifras: Fa#, Si-, La7, Mi7 presentes visualmente.
- achadosAlinhamento: Cifras na mesma sequência, mas Si-/La7 colados e palavras aglutinadas.
- achadosRepeticoes: Refrão completo duas vezes e chamada final presentes.

### 061 — Eis o meu servo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eis-o-meu-servo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0bf04c27378dc497-pair.jpg)

- achadosLetra: ‘Eis o meu’→‘Eis omeu’, ‘Farei descansar’→‘Fareidescansar’, ‘nem gritará’→‘nemgritará’.
- achadosCifras: La-, Re-, Mi7 presentes; sem discrepância de altura destacada nesta leitura.
- achadosAlinhamento: Sequência preservada com cifras mais comprimidas; ancoragem prejudicada por junções.
- achadosRepeticoes: Linhas duplicadas do refrão presentes.

### 062 — Eli, Eli, lamá sabactani

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eli-eli-lama-sabactani.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/07bf88d1ef6ac36e-pair.jpg)

- achadosLetra: Junções extensas: ‘barroseco’, ‘malfeitoresme’, ‘rost quando’/‘rostoquando’; pontuação e ruído espalhados.
- achadosCifras: La- do início aparece La sem menor; asteriscos e cifra ocasional Mi7 perdem relação de rodapé.
- achadosAlinhamento: Muitas cifras e versos com enormes distâncias verticais, legenda ocasional Mi7 separada.
- achadosRepeticoes: Chamadas ELl mantidas mas fragmentadas; leitura exaustiva da transcrição não concluída devido à densidade de falhas.

### 063 — Em meio a multidão

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/em-meio-a-multidao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e6f8939d82e317ee-pair.jpg)

- achadosLetra: ‘disse a Cristo: Fui eu!’→‘disse aCristo:Fuieu’; ‘Filho de’→‘Filhode’. Título residual vira ‘MiM MEIO La MULTIDAO’.
- achadosCifras: Texto do título confundido com cifras vermelhas; demais La-/Sol/Fa/Mi visíveis.
- achadosAlinhamento: BIS A. do bloco esquerdo desloca-se para próximo do texto na coluna direita; versos quebrados artificialmente.
- achadosRepeticoes: Abrangência dos dois BIS perdida; não aprovar execução/repetição.

### 064 — Em Tua luz, Senhor, vemos a luz

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/em-tua-luz-senhor-vemos-a-luz.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/add5c544ad022946-pair.jpg)

- achadosLetra: ‘coração’ aparece ‘coraqão’; ‘ó Deus’→‘6 Deus’; várias junções ‘tuaasas’, ‘ficamsaciados’.
- achadosCifras: Mi-/La- presentes; sem erro de altura óbvio na visão geral.
- achadosAlinhamento: Cifras e letras com espaço vertical irregular; BIS desalinhado.
- achadosRepeticoes: Um BIS vira EIS; barras/abrangência do bis perdidas. Capot 1º traste textual presente, hook não verificável na imagem.

### 065 — Em uma noite escura

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/em-uma-noite-escura.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7837993c3d229f9d-pair.jpg)

- achadosLetra: ‘Às escuras e segura’→‘Às escuras esegura’; ‘excepto a que’→‘exceto aque’; ‘nessa noite ditosa’→‘Nessa noiteditosa’.
- achadosCifras: Mi vira MI; Re-9 presente mas diagrama vira ec./Rad, rever ancoragem.
- achadosAlinhamento: ‘porque’ cai isolado sob a linha anterior; cifras e versos se comprimem.
- achadosRepeticoes: BIS A. vira BISA. e sua barra desaparece; chamadas finais presentes.

### 066 — Encontraram-se dois anjos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/encontraram-se-dois-anjos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4fb2798b4bdb1c4a-pair.jpg)

- achadosLetra: ‘e um’→‘eum’, ‘está a Glória de’→‘estáa Glóriade’, ‘No louvor e na’→‘No louvore na’.
- achadosCifras: La-/Re-/Mi visíveis; sem troca evidente de altura.
- achadosAlinhamento: Rodapé transportado para imediatamente após última linha; asterisco correspondente perdido.
- achadosRepeticoes: Instrução repetir canto subindo meio tom presente, mas desconectada do asterisco.

### 067 — Esconde-me no oculto de tua tenda

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/esconde-me-no-oculto-de-tua-tenda.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/524a24a0a1be7979-pair.jpg)

- achadosLetra: ‘coração’→‘coraqao’; ‘minha luz e’→‘minha luze’; ‘contra mim’→‘contramim’.
- achadosCifras: Mi-, Do, Si7, Re presentes; revisão fina após correção dos espaços.
- achadosAlinhamento: BIS A inicial cai na divisa das colunas; cifras com grandes lacunas em relação ao verso.
- achadosRepeticoes: Chamadas mantidas; abrangência do BIS inicial perdida.

### 068 — Escutai ilhas de longe

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/escutai-ilhas-de-longe.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/78b7b32ea8df98d3-pair.jpg)

- achadosLetra: ‘cuja vida é’→‘cujavidaé’; ‘prestai atenção’→‘prestaiatenção’; ‘esquece’ duplicado na estrofe ‘Acaso uma mãe’.
- achadosCifras: La7 inicial→La?; Fa# final de TE LEVO TATUADA→‘Fait’.
- achadosAlinhamento: Palavra esquece em linha isolada e cifras muito afastadas dos versos.
- achadosRepeticoes: BIS sem barra; refrão final completo presente com erro de acorde.

### 069 — Esperei, esperei no Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/esperei-esperei-no-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d47bed970fd4d72a-pair.jpg)

- achadosLetra: ‘charco de’→‘charcode’; ‘Feliz o’→‘Felizo’; ‘tua contade’ já está na ficha e aparece ‘tuacontade’ no HTML (não corrigir só por pressuposição).
- achadosCifras: La-, Mi-, Fa, Mi7 presentes; capot3º traste textual presente.
- achadosAlinhamento: ‘que não segue’ quebrado em três segmentos desalinhados; chamadas com reticências abaixo.
- achadosRepeticoes: BIS A vira BISA. sem barra; chamadas repetidas presentes.

### 070 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/507b05f4d7e93621-pair.jpg)

- achadosLetra: Junções sistemáticas ‘Estãorotasminhasataduras’, ‘pagasminhas’, ‘minhasportasde’.
- achadosCifras: La- Mi do refrão assembleia aparece ‘La:Mi’ (hífen de menor corrompido); demais Fa#/Si- presentes.
- achadosAlinhamento: Cifras iniciais aglutinadas La-Mi; perda de espaçamento altera leitura.
- achadosRepeticoes: Dois blocos GANHAREI MEU REINO e chamada final presentes.

### 071 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ac6f2616c6a8f096-pair.jpg)

- achadosLetra: Alternativa de baixa resolução da70: HTML mostra ruído (‘Corr43:Pease Patins tags’, números de tabela, ‘GAMELARE! WCU REDO’), sem letra utilizável.
- achadosCifras: Cifras viraram números/letras aleatórias; comparação musical exaustiva inviável.
- achadosAlinhamento: Sem alinhamento musical recuperável no HTML.
- achadosRepeticoes: Repetições irrecuperáveis; usar fonte70 mais nítida como alternativa, não é canto novo.

### 072 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fbb59bda6f3232c9-pair.jpg)

- achadosLetra: Alternativa ainda mais desfocada da70: HTML contém somente H1, corpo inteiro ausente.
- achadosCifras: Todas as cifras ausentes no HTML.
- achadosAlinhamento: Corpo vazio.
- achadosRepeticoes: Todas estrofes e repetições ausentes; alternativa inadequada de resolução, não canto novo.

### 073 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-768x768.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1a46b60ed9f6fb85-pair.jpg)

- achadosLetra: Alternativa da70: junções ‘Estãorotas’, ‘acontarsuasmoedas’, ‘jávestiaminha’.
- achadosCifras: Mi- em ‘Mas minha espada’ perde menor (Mi); Fa# vira ‘Faé’, Si- vira Si, Sol vira Sd no fecho.
- achadosAlinhamento: Cifras coladas La-Mi e ancoragem comprometida.
- achadosRepeticoes: Dois blocos GANHAREI presentes; variante não deve ser novo canto.

### 074 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-830x830.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5a107115044c30b7-pair.jpg)

- achadosLetra: Alternativa da70: ‘GANHAREI’→‘GANHARE!’; ‘vou a toda’→‘VOU ATODA’; junções em toda estrofe.
- achadosCifras: Sol→‘So!’; demais Fa#/Si-/Mi- legíveis, mas precisam correção musical.
- achadosAlinhamento: La-Mi colados; distorções e junções impedem ancoragem fiel.
- achadosRepeticoes: Blocos duplicados presentes; não tratar alternativa como novo canto.

### 075 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/88c658852f6c8431-pair.jpg)

- achadosLetra: Alternativa desfocada da70: corpo HTML reduzido a ‘es emmre ee / ee tee / hot anrset’ etc.
- achadosCifras: Todas cifras perdidas.
- achadosAlinhamento: Sem estrutura recuperável.
- achadosRepeticoes: Estrofes/refrões ausentes; rejeitar alternativa baixa resolução.

### 076 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2553fa097f486eca-pair.jpg)

- achadosLetra: Alternativa desfocada da70: ‘minhas portas’→‘MINHAS PONTAS DEBAR EMPAR’; estrofe esquerda vira ruído (‘O ORBITBOF 487 DS’).
- achadosCifras: Muitas cifras inexistentes (‘Fo’, ‘Law’, ‘tm’, ‘ae’); leitura musical inviável.
- achadosAlinhamento: Resíduo de duas colunas sem ancoragem confiável.
- achadosRepeticoes: Blocos de refrão corrompidos; transcrição não exaurida, fonte inadequada.

### 077 — Estão rotas minhas ataduras

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-17-40-07-480x480.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0969aefda8cbd45c-pair.jpg)

- achadosLetra: Alternativa da70: ‘a contar suas moedas’→‘a contar suas moscas’; ‘meu cavalo’→‘Meu caval 56impacenta’.
- achadosCifras: Re-→Re/Ro; Mi→na/ta/am; La-→La e Fa#→Fae.
- achadosAlinhamento: Alinhamento visual não pode compensar cifras erradas e texto truncado.
- achadosRepeticoes: Blocos GANHAREI parcialmente mantidos, conteúdo corrompido; não é canto novo.

### 078 — Este é o dia que fez o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/este-e-o-dia-que-fez-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/496d8474d0db67f3-pair.jpg)

- achadosLetra: ‘É EXCELSA’→‘ÊEXCELSA’; ‘E ENTRAREI’→‘EENTRAREI’; junções ‘graçasaoSenhor’, ‘casade’.
- achadosCifras: La-, Fa, Mi, Do presentes; sem erro óbvio de altura na visão geral.
- achadosAlinhamento: Linhas e cifras separadas por lacunas irregulares e palavras aglutinadas.
- achadosRepeticoes: Chamadas ‘Não morrerei… NA MORTE’ presentes; reticências isoladas.

### 079 — Este é o meu mandamento

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/este-e-o-meu-mandamento.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2d28afe438fb8c78-pair.jpg)

- achadosLetra: O segundo ‘ESTE É O MEU MANDAMENTO’ do refrão inicial está ausente; último ‘ESTE É O MEU MANDAMENTO’ também ausente. Junções extensas.
- achadosCifras: La-/Do/Mi sobre verso desaparecido ficam órfãs. Nota Re-* mantida mas legenda de rodapé fragmentada.
- achadosAlinhamento: Cifras ficam sem letra nos dois versos omitidos.
- achadosRepeticoes: Perda concreta de linha repetida; não aprovar. Rodapé deve continuar como instrução, não verso.

### 080 — Estendo minhas mãos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/estendo-minhas-maos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d9121b7c95dddbcf-pair.jpg)

- achadosLetra: Segunda linha ‘ESTENDO MINHAS MÃOS’ omitida; ‘E GRITO’→‘EGRITO’; ‘entrego o’→‘entregoo’.
- achadosCifras: Re/Sol da linha omitida ficam órfãos; demais Do/La-/Fa presentes.
- achadosAlinhamento: BISA. no meio do espaço em branco; cifras sem verso.
- achadosRepeticoes: Refrão inicial perdeu uma repetição inteira; barra do bis ausente.

### 081 — Estou chamando-Te

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/estou-chamando-te.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/eb1500099f704e66-pair.jpg)

- achadosLetra: ‘TI MINHA’→‘TIMINHA’; ‘a ti grito’→‘a TIGRITO’; ‘Guarda-me tu do’→‘Guarda-me tudo’.
- achadosCifras: Re-, Sol-, Sib, La7 visualmente presentes; sem erro de altura evidente.
- achadosAlinhamento: Junções movem sílabas sob os acordes; compressão grande de estrofes.
- achadosRepeticoes: Repetições ‘que eu me viciaria’/‘que eu unido’ e chamadas presentes.

### 082 — Eu Te amo, Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eu-te-amo-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4c3f3b1157b668fe-pair.jpg)

- achadosLetra: Junções ‘Eute amo’, ‘do profundo das’→‘do profundodas’. Partituras de violino convertidas em letras/números sem notas.
- achadosCifras: Fa# vira Faf na estrofe do mar e chamada EU TE AMO; partitura musical perdida.
- achadosAlinhamento: Notas/asteriscos não apontam mais para pautas; imagem necessária para preservar música.
- achadosRepeticoes: Chamadas presentes, mas interlúdios de violino irrecuperáveis no HTML.

### 083 — Eu venho reunir

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eu-venho-reunir.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fb49a0397f66509b-pair.jpg)

- achadosLetra: ‘virão e verão’→‘virãoeverão’; ‘Porei neles um’→‘Poreinelesum’; ‘sacerdotes para mim’→‘sacerdotesparamim’.
- achadosCifras: Si7 do GLÓRIA vira Si? em várias ocorrências; Fa#, Do#-, Sol# presentes.
- achadosAlinhamento: Cifras do refrão mais próximas mas Si? torna leitura ambígua.
- achadosRepeticoes: Dois GLÓRIA e chamadas presentes.

### 084 — Evenu Shalom alehem

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/evenu-shalom-alehem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bd56f453c4f7c8b3-pair.jpg)

- achadosLetra: Idiomas aglutinados: ‘Et la paix soit’→‘Etlapaixsoit’; ‘und sei der friede mit uns’→‘undseiderfriedemituns’; ‘É MEU’→‘ÉMEU’.
- achadosCifras: Re-, Sol-, La, La7 presentes; sem troca evidente de altura.
- achadosAlinhamento: Longos intervalos cifra/verso; cada idioma perdeu separação de palavras.
- achadosRepeticoes: Refrões e chamadas presentes, mas exigem correção textual de cada idioma.

### 085 — Exultai, justos, no Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/exultai-justos-no-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e960d64abed9ecb4-pair.jpg)

- achadosLetra: ‘É PRÓPRIO’→‘ÉPRÓPRIO’; ‘tocai a cítara com’→‘tocaia citaracom’; ‘anula os’→‘anulaos’.
- achadosCifras: Do/Si7 e demais cifras preservadas visivelmente; melisma presente como texto.
- achadosAlinhamento: Cifras se afastam do verso na segunda coluna; palavras coladas mudam pontos de troca.
- achadosRepeticoes: Chamadas EXULTAI mantidas.

### 086 — Felicidade para o homem

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/felicidade-para-o-homem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/142b314dfc8f3a9e-pair.jpg)

- achadosLetra: Segundo ‘FELICIDADE PARA O HOMEM’ omitido; ‘Viverá do’→‘Viverádo’; ‘vinha fecunda’→‘vinhafecunda’.
- achadosCifras: Re-9 fica órfão sobre verso omitido; diagrama no rodapé vira ec./Rad.
- achadosAlinhamento: Barra de bis perdida, cifra órfã e texto comprimido.
- achadosRepeticoes: Uma repetição textual do refrão perdida; BISA sem abrangência.

### 087 — Feliz o homem

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/feliz-o-homem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5f19fb043705a423-pair.jpg)

- achadosLetra: ‘seus salmos sussurra dia’→‘seus salmossussurradia’; ‘tudo o que ele faz lhe sai bem’→‘tudo oque elefazlhesaibem’.
- achadosCifras: La-/Fa/Sol/Mi visíveis; sem erro evidente de altura.
- achadosAlinhamento: Pontuação parasita acima da assembleia SERÁ COMO; largas lacunas cifra/verso.
- achadosRepeticoes: Repetições e fecho triplo acaba mal presentes.

### 088 — Filhas de Jerusalém

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/filhas-de-jerusalem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/53f07047e6a525e1-pair.jpg)

- achadosLetra: ‘lenho verde’→‘lenhoverde’; ‘hoje estarás comigo’→‘hoje estaráscomigo’; reticência da segunda chamada vira ‘ne.’.
- achadosCifras: La-/Fa/Sol/Mi visíveis; sem erro evidente de altura.
- achadosAlinhamento: BIS A sem barra; cifras com lacunas verticais irregulares.
- achadosRepeticoes: Chamadas e dois Aaaai presentes, mas uma reticência corrompida.

### 089 — Foge, ó meu amado

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/foge-o-meu-amado.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/397e6c495d68638f-pair.jpg)

- achadosLetra: ‘faze-me ouvir tua voz’→‘faze-me ouvirtuavoz’; ‘a paz’→‘apaz’; ‘está aqui, diante de’→‘estáaqui,diantede’.
- achadosCifras: Fa#- presente; instrução Uma batida em Fa#-, livre e Mi presente mas asterisco isolado.
- achadosAlinhamento: BIS sem barra; asterisco deslocado para linha anterior a cervozinho.
- achadosRepeticoes: Refrão/chamada presentes, abrangência do BIS e ligação da nota perdidas.

### 090 — Graças a Iahweh

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/gracas-a-iahweh.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0f9f37c4c8513380-pair.jpg)

- achadosLetra: Junções ‘graçasao’, ‘dosdeuses’, ‘Eleabriu’, ‘um caminho nodeserto’.
- achadosCifras: Mi- final das duas primeiras linhas do refrão vira Mi maior.
- achadosAlinhamento: Espaços e grandes distâncias verticais prejudicam momento dos acordes.
- achadosRepeticoes: Quatro linhas GRAÇAS iniciais e chamadas presentes.

### 091 — Gritai jubilosos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/gritai-jubilosos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/12d497c33eac54ee-pair.jpg)

- achadosLetra: ‘tirareis água’→‘Tirareiságua’; ‘publicai-as em’→‘publicai-asem’; ‘gritai jubilosos’→‘gritaijubilosos’.
- achadosCifras: La-/Sol/Fa/Mi visíveis, sem erro evidente de altura.
- achadosAlinhamento: ‘É’ cai isolado acima de QUE GRANDE…; BIS perde barra.
- achadosRepeticoes: Chamadas presentes; abrangência do BIS inicial não preservada.

### 092 — Hino à caridade

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-a-caridade.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ef61abe86759cb6b-pair.jpg)

- achadosLetra: ‘Ainda que’→‘Aindaque’; ‘não tenho amor’→‘nãotenhoamor’; ‘todos os meus bens aos’→‘todosos meus bensaos’. Referência1ª→12.
- achadosCifras: Do/La-/Fa/Sol visíveis; capot3º traste textual presente.
- achadosAlinhamento: BIS sem barra, voz assembleia perde destaque e ancoragem irregular.
- achadosRepeticoes: Bloco TUDO ACREDITA preservado, mas escopo BIS perdido.

### 093 — Hino a Cristo luz

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-a-cristo-luz.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4a8053056fd4d417-pair.jpg)

- achadosLetra: ‘ó tríplice’→‘6 tríplice’; ‘Vós sois a eterna luz’→‘Vós soisa eternaluz’; ‘ressuscitando da’→‘ressuscitandoda’.
- achadosCifras: Mi-/La-/Si7/Re7/Sol preservados visualmente.
- achadosAlinhamento: Junções alteram leitura sob acordes; geral sequência vertical preservada.
- achadosRepeticoes: Duas NÓS VOS BENDIZEMOS e três Vós sois presentes.

### 094 — Hino a Kenosis

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-a-kenosis.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3049b08a0fddb525-pair.jpg)

- achadosLetra: ‘superiores a ti’→‘superioresa ti’; ‘não reteve avidamente’→‘não reteveavidamente’; ‘Cristo Jesus’→‘CristoJesus’.
- achadosCifras: Mi-/Si7/Sol/La-/Re/Do visíveis; sem erro óbvio de altura.
- achadosAlinhamento: Grandes lacunas cifra/verso nas estrofes e blocos Aleluia.
- achadosRepeticoes: Blocos Cristo Jesus e Aleluia preservados em quantidade aparente.

### 095 — Hino da Ascensão

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-da-ascensao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/201dfcf9cc10fd12-pair.jpg)

- achadosLetra: ‘ó luz de eterna sabedoria’→‘ó luzde eternasabedoria’; ‘o grande’ aparece ‘0 grande’; ‘no templo’→‘notemplo’.
- achadosCifras: La-/Sol visíveis; sem erro óbvio de altura.
- achadosAlinhamento: BISA. sem barra, cifra de cada verso na mesma sequência mas junções alteram ancoragem.
- achadosRepeticoes: Chamadas presentes; escopo do bis perdido.

### 096 — Hino da Páscoa

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-da-pascoa.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a129ac27c89a545f-pair.jpg)

- achadosLetra: ‘aurora tinge de’→‘auroratingede’; ‘no ar o’→‘no aro’; ‘fechava o’→‘fechavao’.
- achadosCifras: La-/Mi7/La7/Re-/Mi presentes; capot3º textual presente.
- achadosAlinhamento: Primeiro BIS substituído por pequeno traço, segundo isolado sem barra.
- achadosRepeticoes: Perda de indicação BIS do primeiro refrão; segundo sem abrangência.

### 097 — Hino do Advento

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-do-advento.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c9e972dc06292dc9-pair.jpg)

- achadosLetra: ‘levante-se a’→‘levante-sea’; ‘nos é’→‘nosé’; ‘ele com’→‘elecom’; ‘E AO’→‘EAO’.
- achadosCifras: Re-/Sol-/La7 visíveis; sem erro óbvio de altura.
- achadosAlinhamento: BIS sem barra; cifra La7 distante e pontuação parasita sobre AO PAI.
- achadosRepeticoes: Refrão presente, mas bis sem abrangência.

### 098 — Iahweh, Tu és meu Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/iahweh-tu-es-meu-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1a2ecf0d7d3a350c-pair.jpg)

- achadosLetra: ‘Louvarei teu nome’→‘Louvareiteu nome’/‘louvareiteunome’; ‘Destruirás a morte para’→‘Destruirása mortepara’.
- achadosCifras: La-/Mi7/Fa/Sol visualmente presentes.
- achadosAlinhamento: BIS A. sem barra; mudança de espaços em versos sob cifras.
- achadosRepeticoes: Três louvarei e duas cada rosto presentes; escopo BIS perdido.

### 099 — Ide e anunciai a meus irmãos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ide-e-anunciai-a-meus-irmaos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b1e8ee1423422fc4-pair.jpg)

- achadosLetra: ‘Filho e do Espírito Santo’→‘Filhoedo Espírito Santo’; ‘lhes havia indicado’→‘lheshaviaindicado’; ‘que ali me’→‘que alime’.
- achadosCifras: Mi La- vira ‘MiLa-’ colado; demais La-/Re-/Sol/Do presentes.
- achadosAlinhamento: ‘tudo o que eu vos ordenei’ fragmenta ‘que’ em outra linha; BIS sem barra.
- achadosRepeticoes: Chamadas e duplas EIS QUE presentes, abrangência BIS perdida.

### 100 — Impropérios

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/improperios.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1e7a950e9625da68-pair.jpg)

- achadosLetra: ‘Ó POVO’ inicial→símbolo ©; ‘sair do’→‘sairdo’; ‘vinha amada’→‘vinhaamada’.
- achadosCifras: La-6 aparece como [La-6] (equivalente), mas diagrama inteiro vira traço/es; demais Mi-/Si7 presentes.
- achadosAlinhamento: Rodapé diagrama destruído; cifra ocasional não explica sua posição no instrumento.
- achadosRepeticoes: Duas QUE MAL e chamadas presentes; texto grego/latim majoritariamente legível, precisa revisão.

### 101 — Já vem o meu Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ja-vem-o-meu-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5d76b444d26377b7-pair.jpg)

- achadosLetra: ‘operário nascido’→‘operárionascido’; ‘cheio de dor’→‘cheio dedor’; ‘olhos de’→‘olhosde’.
- achadosCifras: Mi-/Si7 visíveis; capot3º textual presente, sem erro óbvio de altura.
- achadosAlinhamento: ‘É um pobre’ quebra em linhas artificiais; cifras ficam longe de frases.
- achadosRepeticoes: Quatro versos iniciais, respostas e chamadas preservados.

### 102 — Jerusalém reconstruída

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/jerusalem-reconstruida.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/70438072d4ec409d-pair.jpg)

- achadosLetra: ‘safiras e esmeraldas’→‘safiras eesmeraldas’; ‘torres de’→‘torresde’; ‘a ti povos’→‘atipovos’.
- achadosCifras: La-/Sol preservados visualmente.
- achadosAlinhamento: Acentos/pontuação de JERUSALÉM surgem como marcas isoladas; cifras afastadas.
- achadosRepeticoes: Refrão quatro linhas, chamadas e dois blocos Aleluia presentes.

### 103 — Jesus percorria todas as cidades

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/jesus-percorria-todas-as-cidades.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/808a87d1d9818ebb-pair.jpg)

- achadosLetra: ‘E vendo’→‘Evendo’; ‘disse aos seus discípulos’→‘disseaos seusdiscípulos’; ‘pai ou sua mãe’→‘paiou suamãe’.
- achadosCifras: Mi- inicial da resposta ESTAVAM e Mi final preservados; demais La-/Re-/Mi7/Do/Sol presentes.
- achadosAlinhamento: BIS sem barra; palavras ‘no’ parasitas na segunda coluna e pontuação isolada.
- achadosRepeticoes: Repetições das respostas presentes, escopo BIS perdido.

### 104 — Leva-me ao céu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/leva-me-ao-ceu.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fa95cfbb6a807ea1-pair.jpg)

- achadosLetra: ‘ó que doce’→‘6que doce’; ‘Uma coisa te rogo’→‘Uma coisaterogo’; ‘estar contigo’→‘Estarcontigo’.
- achadosCifras: Do#- de É CERTAMENTE e não duvidar vira Do# maior; alteração de qualidade concreta.
- achadosAlinhamento: ‘Ó que doce’ fragmentado em duas linhas, parêntese parasita antes de chamada.
- achadosRepeticoes: Duplas iniciais e respostas mantidas, com um doce fragmentado.

### 105 — Levanto os meus olhos para os montes

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/levanto-os-meus-olhos-para-os-montes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c069bf3e50e3be51-pair.jpg)

- achadosLetra: ‘QUE FEZ O CÉU E A TERRA’→‘… E ATERRA’; ‘Ele protege tua vida’→‘Eleprotegetuavida’; ‘Ele guarda tuas’→‘Eleguardatuas’; ‘De dia não te fará mal o sol’→‘Dedia nãotefarámal osol’.
- achadosCifras: Si7 vira S7 em múltiplas linhas; Si La vira Sila colado; Sol#- presente.
- achadosAlinhamento: Cifras órfãs muito acima de QUE FEZ; junções e distâncias prejudicam trocas.
- achadosRepeticoes: Refrão duplicado e chamadas presentes; precisa recompor cifras.

### 106 — Louvai o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/louvai-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/634b47f1bb728869-pair.jpg)

- achadosLetra: ‘é eterna a sua’→‘é eterna asua’; ‘forte é seu’→‘forteéseu’; ‘fidelidade dura para sempre’→‘fidelidadedura parasempre’.
- achadosCifras: Sol/La-/Do/Si7 presentes; melisma classificado como texto vermelho isolado.
- achadosAlinhamento: Asteriscos de melisma flutuam acima das frases; junções alteram leitura.
- achadosRepeticoes: Chamadas e Nações mantidas, instrução melisma presente mas ligação visual fraca.

### 107 — Louvai o Senhor nos céus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/louvai-o-senhor-nos-ceus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/83c99660b5ea38b2-pair.jpg)

- achadosLetra: ‘no alto firmamento’ fragmenta ‘no’ abaixo; ‘grandes peixes e abismos’→‘grandes peixeseabismos’; ‘animais domésticos’→‘animaisdomésticos’.
- achadosCifras: Fa#- das duas linhas iniciais vira ‘Fade’ (perda acidente e qualidade).
- achadosAlinhamento: Quebras artificiais ‘répteis e pássaros que voam’; resposta final nessa linha fica antes da conclusão.
- achadosRepeticoes: Respostas LOUVAI-O presentes, mas uma resposta fica intercalada no verso.

### 108 — Magnificat

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/magnificat.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9358cdd7a9978f39-pair.jpg)

- achadosLetra: ‘A GRANDEZA’→‘AGRANDEZA’; ‘Desde agora me’→‘Desdeagorame’; ‘FEZ GRANDES’→‘FEZGRANDES’; ‘E AOS’→‘EAOS’.
- achadosCifras: Interlúdio La|Mi|La vira ‘La MiLa’ com barras em linha abaixo; demais Re/La/Mi/La7 presentes.
- achadosAlinhamento: Muito espaço vertical entre cifras e versos; barras do interlúdio perdem associação.
- achadosRepeticoes: BIS sem barra/abrangência; chamadas e respostas presentes.

### 109 — Maria, casa da benção

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-casa-da-bencao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ff058cff59279c7e-pair.jpg)

- achadosLetra: ‘viste que nos faltava o vinho’→‘visteque nosfaltavaovinho’; ‘E tu’→‘Etu’; ‘a obedecer-lhe’→‘aobedecer-lhe’.
- achadosCifras: Re-/Sol-/La7/Sib/Do presentes; sem troca evidente de altura.
- achadosAlinhamento: Letra parasita ‘a’ acima de SALVAÇÃO; BIS sem barra; junções prejudicam sílabas.
- achadosRepeticoes: Refrão, VITÓRIA e duas Aleluia presentes, mas escopo BIS perdido.

### 110 — Maria de Jasna Göra

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-de-jasna-gora.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/707c2b7fefceaca6-pair.jpg)

- letra: Uniões indevidas: salva-noscomo, pornós, intercedecomo, aseguir e deCristo.
- cifra: Mi, Re- e La- legíveis preservados nos trechos comparados.
- alinhamento: Mi de ora pro nobis deslocado mais à esquerda em relação à palavra nobis; linhas e espaços precisam recomposição.
- repeticao: Chamadas MARIA... mantidas; variante estendida não inspecionada.

### 111 — Maria, Mãe da Igreja

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-mae-da-igreja.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fd569c4a5174e543-pair.jpg)

- letra: Perde E em E ENSINA-NOS; palavras unidas eisoteuFilho, Eisatua e transpassou-lheoladocom.
- cifra: Fa7 aum quebrado: aum aparece em linha isolada abaixo da cifra nos dois ENSINA-NOS; qualidade fica separada do acorde.
- alinhamento: La- fica isolado longe de MARIA MINHA MÃE; pontos/nomes dos diagramas entram como conteúdo espúrio.
- repeticao: Duas passagens ENSINA-NOS e duas QUE NASCE aparecem; não aprova expansão.

### 112 — Maria, Mãe do caminho ardente

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-mae-do-caminho-ardente.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/87bf2e11ef5a1a9f-pair.jpg)

- letra: Uniões orvalhode, mostrasteo, acruz e dizernão, ausentes na ficha.
- cifra: Sol Mi- Do La e mudanças Re/Sol legíveis mantidas, mas Mi-Do e Sol Mi- ficam aglutinados sem separação suficiente.
- alinhamento: Cifras em geral acima das frases correspondentes, dependem de restauração de espaços da letra.
- repeticao: Repetições explícitas tu nos livras/com o orvalho e sob a cruz presentes.

### 113 — Maria, pequena Maria

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-pequena-maria.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/524e18d363b45d3c-pair.jpg)

- letra: Uniões abrisasuave, sussurrodo, lugarjuntoa, afenda e Santúarioda.
- cifra: Fa#- e Mi-6 preservam acidente/qualidade nos trechos legíveis.
- alinhamento: Cifra Re de Tu és o lugar aparece afastada verticalmente da letra; diagrama final vira ruído | e. e:.
- repeticao: VENHA O SENHOR CONOSCO final permanece abreviado conforme ficha.

### 114 — Maria, pomba incorrupta

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/maria-pomba-incorrupta.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f15992d377eabc9b-pair.jpg)

- letra: Uniões radiantecomo, confinsda, belaacriação, refugiodas e EspíritoSanto; acentos de refúgio/ESPÍRITO perdidos.
- cifra: Fa# vira Faf em faz bela a criação e dá-lhe novo vigor: acidente incorreto.
- alinhamento: Mi- sobre POMBA INCORRUPTA afastado verticalmente; refrão e versos mantêm duas colunas.
- repeticao: Chamadas AVE MARIA... preservadas.

### 115 — Misericórdia minha, misericórdia

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/misericordia-minha-misericordia.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/467bfe272587248a-pair.jpg)

- letra: Uniões Lavai-metodointeiro, Vede,Senhor, coraçõesquesão; Ó Senhor vira 6 Senhor em Abri meus lábios.
- cifra: Re-, Sol- e Do preservados nos pontos legíveis.
- alinhamento: Re- da resposta PURIFICAI-ME aproximadamente conservado; texto condensado prejudica ancoragem fina.
- repeticao: Chamadas de misericórdia e sequência das respostas presentes; expansão não examinada.

### 116 — Mostrar-me-ás o caminho da vida

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/mostrar-me-as-o-caminho-da-vida.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/dad50034bba494bb-pair.jpg)

- letra: Uniões time, vidaestá, noiteinstruimeu, carn edescansa (carne+descansa unidas), teusanto e acorrupção.
- cifra: Mi-, La-, Si7 e Do legíveis preservados; nenhum acidente novo observado.
- alinhamento: BIS A. vira BISA no meio; porque/não abandonarás quebra em ordem visual defeituosa e cifras ficam longe das linhas.
- repeticao: Indicação BIS A. corrompida; chamadas MOSTRAR-ME-ÁS perdem acento em abreviações.

### 117 — Muito me perseguiram

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/muito-me-perseguiram.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3a7c3687d26425be-pair.jpg)

- letra: Uniões perseguiramdesde, costas araram→costasararam, rédeasdos, ervaque e dela o que→delaoque.
- cifra: La- e Mi mantidos nos trechos legíveis.
- alinhamento: La- antes MAS NÃO PUDERAM fica em linha muito afastada.
- repeticao: Perde a segunda linha MUITO ME PERSEGUIRAM, no primeiro refrão: salta de DESDE A JUVENTUDE para MAS NÃO PUDERAM.

### 118 — Não está aqui, ressuscitou

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/nao-esta-aqui-ressuscitou.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c0ce3afce382b012-pair.jpg)

- letra: Uniões outraMaria, eisque, derepentehouve, procuraisJesus e Ressuscitoudentreos.
- cifra: Do-, Re7, Sol- e Re maior distintos mantidos nos refrões; nenhum acidente novo visto.
- alinhamento: Ruído . ) entre segunda resposta da coluna direita; alturas e espaços das cifras variam.
- repeticao: Alternância Não está aqui/E vos precede/Ali o vereis e repetição Ide sem demora presentes.

### 119 — Não há nele aparência

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/nao-ha-nele-aparencia.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b448451eda061b7d-pair.jpg)

- letra: Uniões neleaparência, ne lebelezaque (nele+beleza+que), escóriados e todasasmisérias.
- cifra: Do, La-, Sol e Fa legíveis preservados.
- alinhamento: Cifras e versos muito espaçados verticalmente; La- segue misérias mas palavras coladas exigem recomposição.
- repeticao: Quatro DIANTE DELE... e três Maltratado finais presentes.

### 120 — Noli me tangere

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/noli-me-tangere.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/048d706e39010994-pair.jpg)

- letra: Uniões dize-me,por, poisaindanão, subiao, anunc iaa (anuncia+a), aomeu e EVOSSO.
- cifra: Sib, Sol#, Fa-, Do- e Do legíveis preservados inclusive Do- Do na segunda RABBUNI.
- alinhamento: Cifras Fa/Sol separadas verticalmente de frases em pontos como segundo Senhor.
- repeticao: Três A quem buscas, duas respostas Senhor, duas RABBUNI presentes.

### 121 — Ó céus, chovei do alto

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-ceus-chovei-do-alto.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9bf327e3525d50fd-pair.jpg)

- letra: Uniões ovento, astrevas, ascadeias, afome, ninguémnos e ador.
- cifra: La-, Fa, Sol e Mi preservados nos trechos legíveis.
- alinhamento: BIS A deslocado à direita do bloco; algumas cifras de MARANATHA ficam uma linha afastadas.
- repeticao: Chamadas Maranatha de cada estrofe presentes; BIS permanece indicação do normal, não expansão.

### 122 — O combate escatológico

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-combate-escatologico.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0dfd50128080e992-pair.jpg)

- letra: Uniões céuaberto, cavalobranco, seunome, bestaque, seuprofeta e desangue.
- cifra: Mi, Fa, Sol, Do e La- legíveis mantidos.
- alinhamento: O SEU NOME É desordenado: É vai acima da frase; que se reúnem para um combate fragmentado em posições dispersas.
- repeticao: BIS perdido como delimitação gráfica: texto BIS isolado não define começo/fim do trecho.

### 123 — Ó Deus, pelo Teu nome, salva-me

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-deus-pelo-teu-nome-salva-me.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ea2c89a3cd07f4cb-pair.jpg)

- letra: Uniões arroganteslevantaram-secontramim, umsacrifício, cantareioseu e angústiaele.
- cifra: Fa7 de De toda a angústia vira Fa?; demais Mi-/Mi7, Do7, Re-, La- e Si7 distintos nos trechos legíveis.
- alinhamento: Aglutinações deslocam relação Fa7/Mi7 com palavras; refazer espaços.
- repeticao: Três linhas de toda a angústia e chamada final presentes.

### 124 — Ó Deus, Tu és meu Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-deus-tu-es-meu-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a124787c503134f5-pair.jpg)

- letra: Uniões tiaminha, terraárida, esequiosa, teuNome, estáunidaa e pens oem (penso+em).
- cifra: La-, Re-, Fa e Mi preservados nas passagens legíveis.
- alinhamento: BIS A. vira | BISA. sem delimitador de extensão; acento de É melhor deslocado acima da letra.
- repeticao: Indicação do bloco inicial perdeu delimitação; chamadas Ó Deus... mantidas.

### 125 — O Espírito do Senhor está sobre mim

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-espirito-do-senhor-esta-sobre-mim.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9f5cd1ec239d15ef-pair.jpg)

- letra: Uniões Paraque oscegosvejam, oscoxos, osleprososfiquem e paraanunciar.
- cifra: La- Mi La- da segunda linha inicial ficam órfãos por ausência da letra.
- alinhamento: Cifras órfãs logo antes PORQUE ME UNGIU; demais precisam reancoragem após corrigir palavras.
- repeticao: Omitida a segunda linha O ESPÍRITO DO SENHOR ESTÁ SOBRE MIM do refrão inicial.

### 126 — Ó Jesus, meu amor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-jesus-meu-amor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fd10a7f4612e4c7e-pair.jpg)

- letra: Uniões espinhosda, açoitesda, ofele, vinagrede, fostecrucificadopor, vida de ti→vidadeti e tiatimesmo.
- cifra: La-, Sol, Fa e Mi preservados nos trechos legíveis.
- alinhamento: Cifras Fa/Mi ficam muito acima de para que eu receba a mansidão; asterisco melisma separado da palavra.
- repeticao: Duas quanto me amaste e chamadas dos refrões presentes.

### 127 — O lagareiro

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-lagareiro.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e855d98ef6f63f2b-pair.jpg)

- letra: Uniões ÉESSE, DAVESTE, DEANDAR, ESTÁVERMELHA, ATUA, EFIZCORRER e EUMANCHEI.
- cifra: Mi-, La-, Si7 e Re legíveis preservados.
- alinhamento: Primeira pergunta POR QUE ESTÁ VERMELHA tem fragmentação de espaços e acento deslocado; refazer ancoragem.
- repeticao: Duas PISEI-OS e duas POR QUÊ presentes.

### 128 — O Messias, leão para vencer

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-messias-leao-para-vencer.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/00cd63076b04861b-pair.jpg)

- letra: Uniões leãopara, fez-seCordeiropara, Eseu, Edesceu, Ecom elasubiu e fezentrarna.
- cifra: La-, Mi, Do, Fa e Re- mantidos nos trechos legíveis.
- alinhamento: Compressão de palavras muda posição relativa das cifras; notas 1/2 perdem referência numérica.
- repeticao: Refrão inicial e duas chamadas abreviadas presentes.

### 129 — Ó morte, onde está a tua vitória?

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-morte-onde-esta-a-tua-vitoria.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f97db5852ebba920-pair.jpg)

- letra: Uniões abrirefecharde, trombetafinal, nósseremos, queCristomorreu; título de referência 1ª vira12.
- cifra: Re-5, La-6, Re7, Si, Si- e Mi- legíveis preservados, inclusive diferenças de qualidade.
- alinhamento: Diagramas finais viram 2 | | eo no corpo; algumas cifras muito acima da letra.
- repeticao: Três pares ALELUIA do refrão e chamadas SEGUNDO AS ESCRITURAS presentes.

### 130 — O néscio pensa que Deus não existe

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-nescio-pensa-que-deus-nao-existe.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/45eca0b89c242639-pair.jpg)

- letra: Uniões paraver sehá, quesejajusto, procurea, s edesviaram, nadaos e estácom.
- cifra: Re-, Sol-, La7, Sib, Fa e La- mantidos nos pontos legíveis.
- alinhamento: BIS A. torna-se BIS À isolado e há ruído . ) próximo ao segundo NÃO HÁ QUEM.
- repeticao: Duas NÃO HÁ QUEM e duas um homem que procure presentes; limite do bis perdido.

### 131 — O povo que caminhava nas trevas

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-povo-que-caminhava-nas-trevas.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d3dee3cdf484c025-pair.jpg)

- letra: Uniões luzbrilhou, tuapresença, rejubilamao, repartiremosdespojos e vestesuja.
- cifra: Sol# do primeiro E O SEU NOME SERÁ virou Sol: sustenido omitido; segundo Sol correto.
- alinhamento: Cifras dos versos seguem frases mas dependem de reespaçamento das palavras unidas.
- repeticao: Duas E O SEU NOME SERÁ e duas PRÍNCIPE DA PAZ presentes.

### 132 — O Senhor anuncia uma notícia

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-anuncia-uma-noticia.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/231851283ea74a7e-pair.jpg)

- letra: Uniões vósdormis, prataas, brilhodo, elacai aneve, cavalgaos e vozpoderosa.
- cifra: Sol, Mi-, La-, Si- e La maior em Monte Sombrio/voz preservados.
- alinhamento: BIS A. sem barra de extensão torna escopo do refrão incerto; palavras unidas mudam âncoras.
- repeticao: Duas FOGEM e duas chamadas finais preservadas; bis normal requer delimitação.

### 133 — O Senhor é meu pastor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-e-meu-pastor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/55aa680c37620918-pair.jpg)

- letra: Uniões forças e→forçase, restauraminhas, vápor valeescuro, teubastão, teucajado e casaeternamente; acentos de cál ice/É dispersos.
- cifra: La-, Fa, Mi e Sol legíveis preservados.
- alinhamento: La- de apascenta-me e de vais comigo muito afastado verticalmente; ruído de acentos sobre ATÉ AS ÁGUAS.
- repeticao: Duas restaura minhas forças e três porque tu presentes; chamadas finais mantidas.

### 134 — O Senhor é minha luz e salvação

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-e-minha-luz-e-salvacao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a3cda75f34ef6892-pair.jpg)

- letra: Uniões podereitemer, defensorde, farátremer, coisapeço, habit arna casado e estendesua.
- cifra: Re-, Sib, Do, Sol, Sol- e La7 preservados nos pontos legíveis.
- alinhamento: Cifras muito condensadas em o que poderei temer; restaurar espaços para âncoras.
- repeticao: Três ESPERA NO SENHOR SÊ FORTE e último ESPERA presentes.

### 135 — O Senhor me deu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-me-deu.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6a753c9f1c45ca65-pair.jpg)

- letra: Uniões línguade, palavra de→palavradeconforto, eujá sabia→eujásabia, porissopus e rosto não→rostonãodesvieidos.
- cifra: Fa#- do primeiro O SENHOR vira Faf-; Si- sobre que tu havias de ajudar-me vira Si sem menor.
- alinhamento: BIS isolado sem delimitação; cifras de SE TU SALVAS QUEM ME CONDENARÁ ficam afastadas.
- repeticao: Respostas E EU NÃO RESISTI duplicadas presentes; bis perdeu âmbito gráfico.

### 136 — Ó Senhor, nosso Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-nosso-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bb51b52cd9e20e91-pair.jpg)

- letra: Ó Senhor vira 6Senhor; uniões Pelaboca, criançase, parareduzirao, silêncioinimigos e delecuid ares→delecuid ares sem espaço normal.
- cifra: Mi-, Sol, Si7, La- e Do legíveis preservados.
- alinhamento: Si7 de para reduzir ao silêncio muda âncora após aglutinação; demais requerem reespaçar letra.
- repeticao: Duas no entanto e duas chamadas Ó SENHOR presentes.

### 137 — Olhai que estupendo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/olhai-que-estupendo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d0b702fad8b4ed01-pair.jpg)

- letra: Uniões ung uentoperfumado (unguento+perfumado), descepelabarbade, orvalhodo e vidaeternamente.
- cifra: Mi-, Do, Si7 e La- preservados; sequência Si7 / Do / Si7 legível.
- alinhamento: Que desce quebrado com que abaixo de desce nas estrofes de unguento/orvalho.
- repeticao: Omitida a segunda OLHAI QUE ESTUPENDO do refrão inicial: há Mi- órfão antes PROVAI QUE ALEGRIA.

### 138 — Os meninos de Belém

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/os-meninos-de-belem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/66eb5c386cdb055e-pair.jpg)

- letra: Uniões DOISE, ECAMELOS, MagosMagos, denoitenãopossodormir, por quevi (porque+vi), VISTEUMA e MagosViemos.
- cifra: Fa# da retomada DE ONDE VINDES na direita vira Faf; Si-, La7, Sol, Re e Mi legíveis em outros pontos.
- alinhamento: Papéis Crianças/Magos misturados ao texto; mas de noite... de Gaspar fragmentado com mas e posso abaixo.
- repeticao: Vozes dos três reis e reprises existem, mas junções/fragmentação exigem revisão completa da transcrição.

### 139 — Pentecostes

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/pentecostes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f9523f20ca816871-pair.jpg)

- letra: Uniões ÉUMA, pobreshomens, asredes, taxàsàs→taxasàs, geloapertava, olhoscheiosde e praçascantando.
- cifra: Re-, Do, La, Fa, Sib e La7 preservados nos pontos legíveis.
- alinhamento: Que uma mão de gelo... fica que abaixo de uma mão; cifras de É UM FOGO ficam muito acima da linha.
- repeticao: Chamadas SE SENTES e resposta O REINO DE DEUS JÁ CHEGOU presentes.

### 140 — Por amor de meus amigos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/por-amor-de-meus-amigos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1d8edc916c7f4871-pair.jpg)

- letra: Uniões tediga, alegriaquando, aCasa, lásobem astribos, astribosdo e paraJerusalém; acento PÉS vira PES com ruído.
- cifra: Mi- na linha LA LALALALALA vira MI- com I maiúsculo, grafia não padronizada; La-/Si7 preservados.
- alinhamento: Si7 de OS NOSSOS PÉS muito distante verticalmente; acentos/pontos separados entram no corpo.
- repeticao: Quatro JERUSALÉM JERUSALÉM DE NOVO... iniciais e duas LA... finais presentes.

### 141 — Por que confabulam as nações?

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/por-que-confabulam-as-nacoes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/38e9a240c4057382-pair.jpg)

- letra: Uniões ECONTRA, osseus, assuas, aqueleque, anunciarei o→Anuncia reio, decretodo e confinsda; constituí perde acento.
- cifra: Mi-, La- e Si7 legíveis mantidos.
- alinhamento: Cifras afastadas do segundo EU O CONSTITUÍ; ruídos de acento e ) entre palavras.
- repeticao: Duas EU O CONSTITUÍ e quatro EM SIÃO presentes, chamadas finais preservadas.

### 142 — Por que esta noite é diferente

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/por-que-esta-noite-e-diferente.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ec7b7edd41e29682-pair.jpg)

- letra: Por que vira Porque; uniões estanoiteé, detodas, outrasnoites, enão, deterjantado e paraestartodos.
- cifra: La-, Re- e Mi legíveis mantidos; La- fica órfão no bloco final direito.
- alinhamento: Bloco final direito perde linha sob La- e gera ponto isolado; ancoragem dessa cifra quebrada.
- repeticao: Omitida linha POR QUE ESTA NOITE É DIFERENTE em maiúsculas no último bloco antes das duas DE TODAS AS OUTRAS NOITES.

### 143 — Porque o meu jugo é suave

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/porque-o-meu-jugo-e-suave.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7c299183883c2668-pair.jpg)

- letra: Uniões Vindea, todosvós, euvos, sobrevós, aprendeidemim, ehumilde, decoração (de+coração) e ÉSUAVE.
- cifra: Do, Mi, La- e Fa presentes; Fa órfãs nas duas linhas omitidas do refrão.
- alinhamento: Duas Fa aparecem sem a linha correspondente; reposicionar após restauração.
- repeticao: Omitidas segunda e terceira ocorrências PORQUE O MEU JUGO É SUAVE do refrão: só primeira e duas E O MEU FARDO permanecem.

### 144 — Quando Israel saiu do Egito

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quando-israel-saiu-do-egito.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/cfdfaec814c4add5-pair.jpg)

- letra: Uniões ea casadeJacóde, povobárbaro, Judáfoiseusantuário, eIsrael, osm ontessaltaramcomo (os+montes+saltaram+como), ETU e SALTAISCOMO.
- cifra: Fa# final em QUE FAZ BROTAR vira Fat; Fa# anterior e Si- preservados.
- alinhamento: Aglutinações alteram âncoras de Fa/Mi nos versos iniciais.
- repeticao: Nota Repete-se todo o canto em um tom mais alto presente, mas asterisco de vínculo não aparece.

### 145 — Quando o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quando-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3c9f63c67c90d43f-pair.jpg)

- letra: Uniões parecia-nossonhar, coisastem e fezconosco; língua perde acento.
- cifra: Re, Mi-, Sol, La e [Re7] preservados nos pontos legíveis.
- alinhamento: Re de estava cheia de risos muito afastado verticalmente; refazer o espaçamento.
- repeticao: Refrão completo e chamada final presentes.

### 146 — Que estupendo, que alegria

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/que-estupendo-que-alegria.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a86a91918641fcaa-pair.jpg)

- letra: Uniões óleoderramado, sobreafronte, des c epelabarba (desce+pela+barba), deAarão, oSenhor doalto, avida e nosdá.
- cifra: La-, Re-, Mi, Fa, Sol e Do preservados nos pontos legíveis.
- alinhamento: que da estrofe do orvalho cai abaixo de desce, invertendo leitura normal.
- repeticao: Respostas de óleo/orvalho/bênção e chamadas QUE ESTUPENDO presentes.

### 147 — Quem é esta que sobe do deserto

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quem-e-esta-que-sobe-do-deserto.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/34ef28e21df3b91a-pair.jpg)

- letra: Uniões Debaixoda macieiratedespertei, selono teucoração, seloem teubraço, Porqueforteéo, amorte, opodem e setudesses.
- cifra: La-/Re-/Fa da segunda pergunta ficam órfãs onde a letra foi omitida; outros acordes legíveis preservados.
- alinhamento: Cifras órfãs após primeira linha do refrão mostram perda estrutural.
- repeticao: Omitida segunda QUEM É ESTA QUE SOBE DO DESERTO no refrão inicial; três APOIADA EM SEU AMADO preservadas.

### 148 — Quem nos separará

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quem-nos-separara.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b70f426854962754-pair.jpg)

- letra: Fusões 'Seseguros', 'quenem amorte,nem', 'outracriatura', 'nospoderá separardeDeus', 'Atribulação'.
- alinhamento: Linha que nem a morte,nem a vida fragmenta a vida acima do restante; cifras e texto separados em MANIFESTADO.
- repeticao: BIS A. inicial e três retornos QUEM NOS SEPARARÁ sem expansão por extenso.

### 149 — Quero andar

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quero-andar.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4c4d1a1b471ec060-pair.jpg)

- letra: Fusões 'saciar-medelas', 'sãoânsias deamizade', 'deobediência'; última linha LA LA LA... da fonte não aparece no HTML.
- cifra: Mi aparece como Ml em Re- Ml sobre saciar-me e nas ânsias (l no lugar de i).
- repeticao: Retorno NA VEREDA abreviado; vocalização final LA LA LA omitida.

### 150 — Quero cantar

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quero-cantar.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d3d9cfc144e55ee8-pair.jpg)

- letra: Fusões 'TIQUERO', 'meuDeus', 'emti', 'operigo', 'deitadoentreleões', 'despertai,harpae'; ó Deus vira 6Deus.
- cifra: Fa#- sobre misericórdia da primeira estrofe da coluna direita vira Faf-.
- alinhamento: Cifra Mi- separada da linha leões devoradores por grande vão.
- repeticao: BIS A. inicial e seis retornos QUERO CANTAR abreviados.

### 151 — Ressuscitou

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ressuscitou.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6cf8508c732d54f0-pair.jpg)

- letra: Fusões 'Amorte', 'estáa', 'aminha', 'asua', 'sehoje nosamamos', 'elemorremos', 'elevivemos'.
- alinhamento: Cifras e palavras da estrofe Se com ele morremos muito espaçadas verticalmente.
- repeticao: Três retornos RESSUSCITOU permanecem com reticências.

### 152 — Resurrexit

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/resurrexit.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0820bea17497607c-pair.jpg)

- letra: Fusões 'EUSOU', 'morrerájamais', 'tunisto?Crês', 'creioque', 'Filhode Deus', 'devir ao mundo'.
- alinhamento: Diagrama Mi7 do rodapé omitido, resta nome de cifra; barras soltas antes das quatro GLÓRIA na coluna direita.
- repeticao: Retornos RESURREXIT preservam reticências sem expansão.

### 153 — Salve Rainha

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salve-rainha.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5b56614079fcce0d-pair.jpg)

- letra: Fusões 'eesperança', 'echorando', 'nestevalede', 'misericordiososa', 'destedesterro', 'benditofrutodo', 'pornós', 'Paraque'.

### 154 — Salve Rainha dos céus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salve-rainha-dos-ceus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/994252000b9c58a1-pair.jpg)

- letra: Fusões 'rainhados', 'abristeocaminho', 'anossa'; três vogais I... do melisma da fonte não aparecem no HTML.
- alinhamento: La-/Sol/La- do melisma ficam sem sílabas abaixo.
- repeticao: Retorno final ALEGRA-TE VIRGEM MARIA permanece abreviado.

### 155 — Se hoje escutardes a sua voz

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/se-hoje-escutardes-a-sua-voz.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ddc53b05a5285984-pair.jpg)

- letra: Fusões 'exultemosno', 'rochedo', 'seuencontro', 'esalmos', 'ouvísseishoje', 'vistoas', 'fazersuavontade', 'issonão entrarãono'.
- cifra: Sol7 vira Sol? no refrão inicial, aclamemos, adoremos e como no dia de Massa.
- repeticao: BIS A. inicial e quatro retornos SE HOJE ESCUTARDES abreviados.

### 156 — Se me refugiei no Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/se-me-refugiei-no-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/719d3ba9280a1c2d-pair.jpg)

- letra: Fusões 'seique', 'flechasàcorda', 'fazerojusto', 'oSenhor', 'seutemplo', 'tronono', 'escrutaosjustos', 'nãoama'.
- alinhamento: Cifras Do/Si7 na segunda pergunta Que pode fazer o justo afastadas por grande vão vertical.
- repeticao: Retorno SE ME REFUGIEI abreviado.

### 157 — Se o Senhor não constrói a casa

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/se-o-senhor-nao-constroi-a-casa.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7b5a235e56f80a73-pair.jpg)

- letra: Fusões 'Seo Senhornão', 'vigiamas', 'vãovos', 'conseguiropão', 'dáaos seusamigos', 'sãoos', 'Felizohomem', 'portaosinimigos'.
- repeticao: BIS A. inicial e três retornos SE O SENHOR permanecem sem expansão por extenso.

### 158 — Se vós ressuscitastes com Cristo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/se-vos-ressuscitastes-com-cristo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/45fcc94bce1f6a06-pair.jpg)

- letra: Fusões 'Aspiraiàs coisasdo', 'vidaestáoculta', 'Cristoem', 'Cristoaparecer', 'avossa', 'aparecereisgloriososcom'.
- alinhamento: Letras soltas e/na acima de E NÃO ÀS DA TERRA nas duas colunas; acentos viram pontos isolados em ONDE ESTÁ/SENTADO À DIREITA.
- repeticao: BIS A. inicial e dois retornos SE VÓS RESSUSCITASTES abreviados.

### 159 — Seduziste-me Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/seduziste-me-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e4fc5200c75f72b6-pair.jpg)

- letra: Fusões 'Palavraépara', 'corriapormeus', 'Nasceu-teum', 'ventrede', 'verpenas', 'hinosao' e 'louvaiseu'.
- alinhamento: Mi7 de Dizia-me fica afastado da frase por grande espaço vertical.
- repeticao: BIS A. do início e MAS O SENHOR sem expansão; dois retornos SEDUZISTE-ME abreviados.

### 160 — Senhor, ajuda-me a não duvidar de Ti

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/senhor-ajuda-me-a-nao-duvidar-de-ti.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/30c78c682c716f70-pair.jpg)

- letra: Fusões 'nãoduvidardeti', 'nãoduvidarnuncado', 'teuAmor', 'Tuagraça', 'deixoumeu coraçãojáflorescido', 'milânsias', 'nestateiaqueenvolveminha', 'amorobscura', 'TEIAQUE'.
- alinhamento: Cifras da resposta A NÃO DUVIDAR NUNCA ficam distantes verticalmente; acentos/pontos soltos sobre a letra.
- repeticao: Retorno SENHOR AJUDA-ME abreviado até A NÃO DUVIDAR NUNCA.

### 161 — Senhor, não me corrijas na tua cólera

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/senhor-nao-me-corrijas-na-tua-colera.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/48ba3334e469735f-pair.jpg)

- letra: Fusões 'NÃOME', 'estousem', 'sedesmoronam', 'porquearrasadatenho', 'portuamisericórdia', 'Estou cansadode', 'inundodelágrimasminha', 'Senhorescutameus'.
- cifra: Fa# vira Faf em e tu Senhor até quando (solo e resposta final), TE RECORDA e escuta meus soluços.
- alinhamento: Diagrama Fa#5/9dim não reproduzido; fica nome de cifra e caracteres avulsos no rodapé.
- repeticao: BIS A. inicial e QUE NINGUÉM sem expansão; três retornos SENHOR NÃO ME CORRIJAS abreviados.

### 162 — Sequência De Corpus Christi

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/sequencia-de-corpus-christi-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/81e8605357e6327a-pair.jpg)

- letra: Fusões 'louvá-lonão', 'teulouvor', 'elacelebrar', 'foientregue', 'júbilocantemos', 'poistransborda', 'Cristofezna', 'preceitoconhecemos', 'vinhoamigo', 'todocristão', 'vistatutranscendes'.
- alinhamento: É por todos recebido fragmenta por abaixo de É todos recebido, rompendo ordem da frase.
- repeticao: Três respostas TERRA EXULTA só trazem primeira linha; duas usam reticências e nenhuma expande refrão completo.

### 163 — Sequência De Corpus Christi

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/sequencia-de-corpus-christi-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f1b1ba51456d49f4-pair.jpg)

- letra: Fusões 'efeitoébem', 'trazem', 'igualcomida', 'Eisa hóstiadividida', 'partículatambém', 'sinalque', 'Eiso pão', 'filhoso', 'sinaisprefigurado', 'porAbraão foiimolado', 'famíliaassim'.
- alinhamento: Nota vermelha final sobre forma longa/abreviada fragmentada em alturas diferentes; ** da chamada vira wk avulso à esquerda.
- repeticao: Dois retornos TERRA EXULTA permanecem abreviados.

### 164 — Sermão da montanha

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/sermao-da-montanha.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/52f923f7c0cc2e97-pair.jpg)

- letra: Fusões 'Erguendoosolhospara', 'osseusdiscípulos', 'FELIZESVÓS', 'SEREISSACIADOS', 'HAVEISDE', 'avossarecompensa', 'TEREISCHORO', 'AOUTRA', 'E SEREISPERDOADOS'.
- cifra: Si Fa# vira SIFa& em A QUEM LEVAR O QUE É TEU/PERDOAI; SI Faé em NÃO CONDENEIS; fusões SolRe/LaMi prejudicam separação de acordes.
- alinhamento: Cifras SolRe ficam isoladas entre FELIZES VÓS QUE AGORA e TENDES FOME; pontos/acentos avulsos nas respostas.

### 165 — Shlom-lej Mariam

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/shlom-lej-mariam.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/46d5323fa4df2e45-pair.jpg)

- letra: Fusões 'Benditasois', 'entreas', 'ebendito', 'frutodo' e 'aiaiaiai'.
- alinhamento: Mi- inicial da estrofe Ave Maria fica separado da letra por grande vazio.
- repeticao: BIS A. inicial e BIS do refrão não expandidos; retornos SANTA/SHLOM abreviados.

### 166 — Sião, mãe de todos os povos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/siao-mae-de-todos-os-povos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/82e2f6755543bbf1-pair.jpg)

- letra: Fusões 'portasdeSião', 'coisasestupendas', 'Talhomem', 'Estãoem'.
- alinhamento: Primeiro MÃE,MÃE,CIDADE DE DEUS quebra primeiro MÃE em linha acima de MÃE,CIDADE.
- repeticao: Barras/BIS A./BIS mantidos nas respostas sem expansão por extenso.

### 167 — Só a só

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/so-a-so.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d265efdb154731c2-pair.jpg)

- letra: Fusões 'tepoderá', 'torretranspassada', 'tusustentas', 'débilfé', 'SÓASÓ'.
- letra: Nota de dedilhado corrompida: 1ª vira 12 e 4ª vira 42.
- alinhamento: Diagramas de acordes oficiais no rodapé viram caracteres soltos no HTML, sem diagrama utilizável.
- repeticao: Retorno final SÓ A SÓ fica abreviado.

### 168 — Sobe Deus entre aclamações

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/sobe-deus-entre-aclamacoes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a67d04c34752b535-pair.jpg)

- letra: Fusões 'Deusentreaclamações', 'Povostodos,bateipalmas', 'CantaiaDeus'.
- letra: Sinal = avulso sobre ACLAMAÇÕES do retorno final.
- repeticao: Dois retornos SOBE DEUS mantêm reticências e BISA com barra; falta texto repetido por extenso.

### 169 — Stabat Mater dolorosa

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/stabat-mater-dolorosa.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1c4bc74dd2d06fe7-pair.jpg)

- letra: Fusões 'atranspassou', 'benditaMãe', 'tantosuplício', 'aosaçoites'; subtítulo século XIII vira séculoXII.
- cifra: Do7/Sib7 iniciais viram Do?/Sib?; o mesmo par corrompido em Ó que triste e aflita.
- alinhamento: Diagrama Re-5 do rodapé vira caracteres isolados, sem desenho utilizável.
- repeticao: BIS inicial e final sem expansão; dois retornos STABAT abreviados.

### 170 — Tu cobriste de vergonha a morte

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tu-cobriste-de-vergonha-a-morte.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ecec78a78223e4b1-pair.jpg)

- letra: Fusões 'Tunos', 'daescravidãoà', 'cordeironascido', 'fosteassassinado', 'cordeiroque'.
- cifra: La7 vira La? em A MORTE, da morte à vida e Tu foste tirado.
- alinhamento: COMO MOISÉS AO FARAÓ traz pontos soltos sobre palavras; várias cifras distantes verticalmente.
- repeticao: BIS A. inicial sem expansão; dois retornos MARIA abreviados.

### 171 — Tu és digno de receber o livro

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tu-es-digno-de-receber-o-livro.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/72e5ff1640872d00-pair.jpg)

- letra: Fusões 'Tués', 'olivro', 'abriros', 'tufosteimolado', 'povoenação'.
- letra: Segunda estrofe 'teu o sangue' da fonte aparece como 'teuo sangue', sem separação.
- repeticao: Dois retornos E FIZESTE DELES ficam abreviados.

### 172 — Tu és formoso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tu-es-formoso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d6e60f046ad2c6a2-pair.jpg)

- letra: Fusões 'cavalgacheio', 'pelaverdade', 'faztemívelatuadireita', 'Dospaláciosde', 'tufaráspríncipessobrea'.
- cifra: Fa#- sobre Agudas vira Faf-.
- alinhamento: Parêntese/pontos avulsos acima de A GRAÇA e TU ÉS BENDITO.
- repeticao: Três retornos TU ÉS FORMOSO ficam abreviados.

### 173 — Tu que és fiel

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tu-que-es-fiel.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/49041944c57d5009-pair.jpg)

- letra: Fusões 'juízoo teu' / 'juízooteu', 'inimigopersegue-me', 'vidacontrao', 'comoterraressequida', 'teuEspíritome'.
- alinhamento: Cifras Sol-/Do- da primeira resposta muito afastadas da letra; pontos/acento avulsos sobre resposta.
- repeticao: Quatro retornos TU QUE ÉS FIEL ficam abreviados.

### 174 — Um grande sinal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/um-grande-sinal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f2313c540028e7c3-pair.jpg)

- letra: Fusões 'outrosinalno', 'setecabeças', 'edez', 'colocou-sediante', 'Filhotãologo', 'batalhoujuntamente'.
- letra: 'encontrou mais' da fonte vira 'enconiroumais'.
- repeticao: Dois retornos UM GRANDE SINAL ficam abreviados; final LA LA também traz reticências.

### 175 — Um rebento brota do tronco de Jessé

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/um-rebento-brota-do-tronco-de-jesse.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/20bcd47e03b3e93e-pair.jpg)

- letra: Fusões 'EFORTALEZA', 'julgarápor ouvirdizer', 'palavraserá', 'contraoviolento', 'novilhopastarãojuntos', 'araizde'.
- alinhamento: Parêntese avulso entre cifras e resposta PORQUE UM CAMINHO SE ABRIRÁ; cifras muito apartadas em leão/menino.
- repeticao: Dois retornos UM REBENTO BROTA ficam abreviados.

### 176 — Uri, uri, uri urá

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/uri-uri-uri-ura.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/410bda186380cce0-pair.jpg)

- letra: Primeiros uri/urá em solo perdem acento (ura); fusões 'vainascer', 'sechamará', 'paié', 'LALALALA'.
- alinhamento: Si7 fica órfão antes de PAM; pontuação solta entre cifra e texto de LA LA e COMO SE CHAMARÁ.
- repeticao: Na primeira resposta há só duas linhas URI explícitas antes de PAM, contra três na fonte; retornos finais URI abreviados.

### 177 — Vamos já, pastores

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vamos-ja-pastores.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/67e3b6c4313340ba-pair.jpg)

- letra: Fusões 'JÁ,PASTORES', 'jácantam', 'járiem', 'pai,José'.
- alinhamento: Grandes vazios verticais no refrão inicial tornam distante a associação das cifras a SE CHAMA EMANUEL.
- repeticao: BIS do PA RA RAM PAM PAM preservado sem expansão; dois retornos VAMOS JÁ abreviados.

### 178 — Vem do Líbano

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vem-do-libano.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fd6ccba2824767e4-pair.jpg)

- letra: Ó irmã e ó esposa viram '6irmã' e '6esposa'; fusões 'Teráspor', 'coroaos', 'osaltoscimos', 'Eupertençoao', 'eleé tudoparamim', 'rolaseouve'.
- alinhamento: Mi-/Re da estrofe Como um selo ficam separados da linha por espaço vertical; ponto avulso acima de NÃO.
- repeticao: Três retornos BUSQUEI O AMOR continuam abreviados.

### 179 — Vem, Espírito Santo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vem-espirito-santo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/abb3e82e64d38c72-pair.jpg)

- letra: Omitidas “ENVIA UM RAIO DE TUA LUZ” e “Olha a força do pecado”; fusões “paidos”, “luzdos”, “Dá-nost eus”/“Dá-nosteus”.
- cifra: Do/Fa/Mi iniciais têm alturas nominais equivalentes; Mi fica sem a linha ENVIA correspondente.
- alinhamento: Refrões e palavras repartidos em alturas distintas, com sinais soltos = e parêntese.
- repeticao: Refrões permanecem em reticências, sem expansão integral.

### 180 — Vem, Filho do homem

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vem-filho-do-homem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b81281d58e850b70-pair.jpg)

- letra: Trecho após versos multilíngues contaminado por extensa tabela numérica; sequência Espírito/amor/reprise deixa de ser legível em ordem.
- cifra: Mi-, La-, Si7 e Do reconhecíveis no início; cifras finais isoladas abaixo da tabela perdem vínculo musical.
- alinhamento: Grande tabela ocupa o corpo e texto continua em coluna estreita na borda direita.
- repeticao: Reprise final Filho do homem/amor meu fragmentada entre números.

### 181 — Vem o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vem-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a2312f27b1743b9c-pair.jpg)

- letra: “está firme o mundo” torna-se “estáfirmeo mundo”; “A ELE A” vira “AELEA”; “sacerdotes do” fundido.
- cifra: Mi-/La- mantidos nominalmente nos trechos comparáveis, mas espaços de ancoragem variam.
- alinhamento: Mi- entre estrofes fica isolado, distante de “desde sempre tu és o Senhor”.
- repeticao: BIS literal mantido em dois pontos; refrões com reticências não expandidos.

### 182 — Veni Creator

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/veni-creator.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c18fe7ae6c21351f-pair.jpg)

- letra: “santo crisma da alma” vira “santo crismada alma”; “sara as nossa feridas” fundido e “Luzde eternasabedoria”.
- cifra: Alternância La-/Sol e Sol La- do Amém visível preservada nominalmente.
- alinhamento: Sol/La- comprimidos juntos sobre AMÉM; fusões tornam ancoragem menos precisa.
- repeticao: Não há indicação BIS nem reprise abreviada nesta ficha.

### 183 — Virgem da maravilha

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/virgem-da-maravilha.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ad0401695dac0f86-pair.jpg)

- letra: Omitido “Virgem da maravilha!” ao fim da estrofe da pequena; “filhade Deus” fundido.
- cifra: Si- inicial da estrofe “Maria, tu” aparece Si (perde menor); Fa# em “concebeu” aparece Faf.
- alinhamento: Sol/Fa# da linha omitida ficam soltos na coluna direita.
- repeticao: BIS A. e refrões em reticências mantidos sem expansão.

### 184 — Vivei alegres

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vivei-alegres.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/8a59a664666c26d0-pair.jpg)

- letra: “VIVEI ALEGRES” vira “VIVEIALEGRES”; “Senhor já vem” vira “Senhorjávem”.
- cifra: La-/Mi/La7/Re- do refrão e La maior da estrofe estão nominalmente presentes.
- alinhamento: Fusão JÁVEM muda o espaçamento sob Re-.
- repeticao: Três “E NOS SALVARÁ” iniciais presentes; retorno final só em reticências.

### 185 — Vós sois a luz do mundo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vos-sois-a-luz-do-mundo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/793869a40ba825b0-pair.jpg)

- letra: Fusões “sepode”, “cidadesobre”, “colocadebaixo”, “luzatodos”, “glorifiquemovosso Paique”.
- cifra: La-/Mi/Re-/Do/Fa visíveis com qualidades equivalentes nos versos comparáveis.
- alinhamento: Compressão da letra reduz precisão de entrada dos acordes dentro das frases.
- repeticao: Refrão final somente “VÓS SOIS A LUZ DO MUNDO, ...”.

### 186 — Vos tomarei dentre as nações

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/vos-tomarei-dentre-as-nacoes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/94ff18465761e3a4-pair.jpg)

- letra: “darei um” vira “dareium”; “coração de carne” vira “coração decarne”; “sereis o meu” vira “sereisomeu”.
- cifra: Re-, Re7, Sol-, La e Sib conservados nominalmente, inclusive sétima e bemol.
- alinhamento: Fusões alteram espaçamento sob Sib/La nas linhas de carne/povo.
- repeticao: Ambos retornos do refrão permanecem abreviados.

### 187 — Zaqueu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/zaqueu.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f361ff284bedd3ac-pair.jpg)

- letra: Fusões “Vivia alium”, “chefede”, “Eleiapassar”, “entrena tuacasa”, “Filhodo homem”.
- cifra: La-/Sol/Fa/Mi e Re- das chamadas finais reconhecíveis; ancoragem deslocada por espaços excessivos.
- alinhamento: “ÉS” separado acima de ZAQUEU/TU; grandes intervalos vazios entre linhas.
- repeticao: BIS A. preservado como BISA./barras; retornos TENDO ENTRADO/HOJE abreviados.

### 188 — Como o impulso que sente a ira

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-o-impulso-que-sente-a-ira.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4e26f9d5dbd2d417-pair.jpg)

- letra: “Como o impulso” vira “Como oimpulso”; “tu, o imortal” vira “tu,Oimortal”; “Tu te” vira “Tute”.
- cifra: Sol7 em “amor” e “suavidade” vira Sol? (sétima ilegível/errada).
- alinhamento: Acentos e parênteses soltos acima de TU ÉS O CAMINHO.
- repeticao: Retornos TU ÉS O CAMINHO abreviados.

### 189 — Débora

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/debora.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/5715010ddce1d81a-pair.jpg)

- letra: “não havia caravanas” vira “não haviacaravanas”; “desde os céus lutaram contra Sísara” fundido; “a torrente sagrada os” vira “atorrentesagradaos”.
- cifra: Re7, Mi-, Fa, Mi e La- visíveis preservados nominalmente.
- alinhamento: Mi de LEVANTA-TE BARAC muito afastado verticalmente; pontuação solta sobre DESPERTA.
- repeticao: Dois blocos DESPERTA distintos presentes, mas BENDIZEI retorna com reticências.

### 190 — Eis que o nosso espelho é o Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/eis-que-o-nosso-espelho-e-o-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9d967e6979f7bc5e-pair.jpg)

- letra: Verso “Aleluia, aleluia, aleluia” contaminado com “elui ... ui ... ui”; “espelho é o Senhor” e “limpai a imundície do” fundidos.
- cifra: Re-/La-/Sol-/La preservados nominalmente.
- alinhamento: Palavras fundidas sob acordes finais alteram ancoragem.
- repeticao: BIS literal nos dois refrões, sem texto repetido integralmente.

### 191 — Hino à cruz gloriosa

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/hino-a-cruz-gloriosa.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4ccb0f825bea38e4-pair.jpg)

- letra: Fusões “orvalhome”, “eupus”, “minhatenda”, “Notemor”, “devidaeterna”, “braçosabertos”.
- cifra: Sustenidos e menores Mi/Sol#/Do#-/Fa#- e Si7 visíveis; no verso “Árvore” Fa# - fica separado, exigindo normalização.
- alinhamento: Sol# de fecunda flutua muito acima da linha; cimo/céu colado ao verso anterior.
- repeticao: Dois retornos A CRUZ GLORIOSA em reticências.

### 192 — Jacó

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/jaco.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ed9413bcd87ebbc2-pair.jpg)

- letra: “Era já noite quando” vira “Erajánoitequando”; “tocou-lhe a articulação da” vira “tocou-lheaaarticulaçãoda”; “Não te chamarás” perde acentos.
- cifra: La-/Fa/Mi/Sol/Do/Re e Mi7 presentes nominalmente, inclusive menor e sétima.
- alinhamento: Acentos substituídos por parênteses sobre ISRAEL SERÁ/TE APOIARÁS; grandes vazios entre versos.
- repeticao: Bloco final de oito linhas ISRAEL presente, mas texto perdeu acentos e separação.

### 193 — Não resistais ao mal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/nao-resistais-ao-mal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/73c300131d37349d-pair.jpg)

- letra: Fusões “teferena”, “oferece-lhetambém”, “levaajuízopara”, “bem aos”→“bemaos”, “fazsurgirosol”.
- cifra: Re/Si-/La/Sol conservados nominalmente nos trechos comparados.
- alinhamento: “E se alguém” e continuação te leva fragmentados verticalmente com Si- muito distante.
- repeticao: Quatro NÃO RESISTAIS iniciais presentes; retornos abreviados em três pontos.

### 194 — Não sofras pelos malvados

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/nao-sofras-pelos-malvados.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/403076f955e844a0-pair.jpg)

- letra: “faze o bem” vira “fazeo bem”; “te dará” vira “tedará”; “herdarão a terra” vira “herdarãoa terra”.
- cifra: La-/Fa/Mi/Re- conservados nominalmente nas linhas verificáveis.
- alinhamento: Mi de “a terra possuirão” flutua acima de grande lacuna.
- repeticao: Dois retornos NÃO SOFRAS abreviados.

### 195 — Ninguém pode servir a dois senhores

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ninguem-pode-servir-a-dois-senhores.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c0c075f33e2ca4b9-pair.jpg)

- letra: “Não podeis servir” fundido; “Buscai primeiro o reino de” vira “Buscaiprimeirooreinode”; “ETUDO” no refrão.
- cifra: Mi-/Re/Do/La-/Re7/Si7/Sol/Si-/Do7 presentes, sem troca nominal evidente.
- alinhamento: Acordes Do7 Do e Si7 flutuam separados de suas linhas por grandes vazios.
- repeticao: BIS literal aves/lírios e retornos finais em reticências, sem expansão.

### 196 — O mesmo Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-mesmo-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7353090c5683546a-pair.jpg)

- letra: “Do seio das trevas brilhe” vira “Do seiodastrevasbrilhe”; “sublime deste amor” fundido; “nós” no refrão perde acento.
- cifra: Fa# inicial sobre disse e Fa# sobre “não vem de nós” aparecem Faf; demais Fa# explícitos permanecem.
- alinhamento: Parêntese isolado acima de NÓS MORREMOS; primeira coluna com vazios que separam acordes e letra.
- repeticao: LEVANDO SEMPRE abreviado duas vezes.

### 197 — O semeador

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-semeador.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/37eac01bb8656d27-pair.jpg)

- letra: “Vieram as aves” vira “Vieram asaves”; “alguns trinta/outros sessenta” fundidos; “Não sejas caminho/pedra/espinho” fundidos.
- cifra: Re-/Do/Fa/Sol/La/Sol- e La7 finais nominalmente presentes; Re- La7 aparece Re-La7 sem separação clara.
- alinhamento: Re- sobre NÃO TINHA TERRA longe da letra; blocos inferiores espaçados excessivamente.
- repeticao: Quatro BIS A. ainda como abreviação; respostas finais presentes mas sem expansão dos BIS.

### 198 — Ó Senhor, meu coração não é pretensioso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/o-senhor-meu-coracao-nao-e-pretensioso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3053f41aa624da65-pair.jpg)

- letra: “É PRETENSIOSO” fundido; “aplaquei e acalmei a minha” vira “aplaqueie acalmeiaminha”; “no colo da sua” fundido.
- cifra: Mi-/La-/Si7/Do presentes nominalmente com qualidades da fonte.
- alinhamento: Compressão ÉPRETENSIOSO altera início do Mi- final; demais âncoras dependem de espaços.
- repeticao: BIS A. inicial e retomadas Ó SENHOR/Mas aplaquei permanecem abreviados.

### 199 — Quando dormia

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/quando-dormia.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/042bad68acaf680a-pair.jpg)

- letra: “Meteu a mão” vira “Meteu amão”; “destilaram mirra” e “mirra fluída meus” fundidos; “Poderia beijar-te” vira “Poderiabeijar-te”.
- cifra: Do/Mi/La-/Re-/Sol/Fa mantidos nominalmente nos trechos visíveis.
- alinhamento: Fa de SE ENCONTRARDES flutua sobre grande vazio; linhas do refrão afastadas.
- repeticao: BIS literal no refrão e retornos abreviados, sem texto integral.

### 200 — Senhor, tu me escrutas e conheces

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/senhor-tu-me-escrutas-e-conheces.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/dbfaf55b7c25becb-pair.jpg)

- letra: “escrutas e conheces” vira “escrutaseconheces”; “língua a palavra” vira “línguaapalavra”; “É CIÊNCIA” vira “ÉCIÊNCIA”.
- cifra: Sol-6 textual mantido; diagrama de posição da fonte desaparece, restando Sol-6 solto no rodapé; Re-/Sol-/Do7/Sib visíveis.
- alinhamento: Cifra de diagrama sem desenho nem verso; fusões “IREILONGE” e “E AO”→“EAO”.
- repeticao: Refrão integral presente uma vez, sem BIS; duplicações de solista/assembleia distinguíveis.

### 201 — Senta-te solitário e silencioso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/senta-te-solitario-e-silencioso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2f50c3a69956ca06-pair.jpg)

- letra: “Retesaste teu arco” vira “Retesastet euarco”/“Retesastetearco”; “minha miséria”, “fel e amargura”, “grande amor” fundidos.
- cifra: La7 em TE FERE e segundo o seu grande amor vira La?; Fa#- e Fa# de O que posso fazer distintos preservados.
- alinhamento: Mi- e La? sobre PÕE TUA FACE separados por grande espaço vazio; fragmento mS no lugar da área BIS.
- repeticao: BIS não expandido e marcador corrompido em mS.

### 202 — Shemá Israel

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/shema-israel.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/71163c2969b33089-pair.jpg)

- letra: “Inculca-as a” vira “Inculca-asa”; “delas fala em casa” vira “delas falaem casa”; “terás, terás a” vira “terás,terása”; nota final fundida.
- cifra: La-/Sol/Fa/Mi/Re- conservados nominalmente; La- órfão na retomada à direita após omissão de SHEMÁ ISRAEL.
- alinhamento: Vazios excessivos e acentos isolados sobre SHEMÁ/É; retomada direita contém só reticências sem texto SHEMÁ.
- repeticao: SHEMÁ/ESCUTA abreviados em diversos retornos; não expandidos.

### 203 — Tu és a minha esperança, Senhor

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tu-es-a-minha-esperanca-senhor.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a8c1d2c4777671c6-pair.jpg)

- letra: “Tu és a minha” vira “Tu ésa minha”; “a tua misericórdia” fundido; “deste o sinal grande” vira “desteo sinalgrande”.
- cifra: Do# dim7 inicial vira Do# dim? e Sib7 seguinte vira Sib?; diagrama Do#dim7 omitido, só rótulo e ruído ad.
- alinhamento: Rótulo Do#dim7 órfão no rodapé; Sib 7 separado no verso guerra.
- repeticao: BIS A.→BISA sem expansão e dois retornos TU ME TIRASTE abreviados.

### 204 — À ceia do cordeiro

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-ceia-do-cordeiro.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4e4972a1188d02a7-pair.jpg)

- letra: “ó Senhor” vira “6Senhor”; “braço potente nos salva” vira “braço potentenos salva”; “cordeiro imolado” fundido.
- cifra: La-/Sol/Fa/Mi e Sol La- final nominalmente preservados.
- alinhamento: “O seu corpo” fragmentado com corpo em outra altura; “os que renovaram” tem que deslocado abaixo.
- repeticao: Quatro retornos À CEIA DO CORDEIRO abreviados, sem texto integral.

### 205 — A pomba voou

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/a-pomba-voou.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/662d03dd0131d0c5-pair.jpg)

- letra: “A CABEÇA” vira “ACABEÇA”; “abismos se” vira “abismosse”; “ouviram-se terríveis” fundido; “sua vontade/santidade” fundidas.
- cifra: La-6 textual preservado com espaço antes do 6 em alguns pontos; diagrama de posição omitido e rótulo órfão no rodapé. Mi-/Si7/La-/Do presentes nominalmente.
- alinhamento: “e deu àqueles que o seguem” fragmentado em três alturas, com o isolado; ruídos e pontos no rodapé.
- repeticao: Dois retornos A POMBA VOOU abreviados em reticências.

### 206 — Como escorre o mel

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-escorre-o-mel.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c672c2018d61854d-pair.jpg)

- letra: Palavras fundidas: 'demeus', 'minhalínguasente', 'sente seu olhar amoroso' vira 'senteseuolharamoroso'.
- alinhamento: Mi acima de 'um canto novo' fica isolado em enorme intervalo vertical no HTML.
- repeticao: Retornos 'COMO ESCORRE O MEL...' e 'PORQUE A VIDA IMORTAL...' permanecem abreviados, sem expansão.

### 207 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0b03e7f1036eb212-pair.jpg)

- letra: 'perfumedemirra', 'repousasobremeu', 'estousentada' fundem palavras.
- repeticao: BIS A. conservado nas duas passagens de 'INTRODUZIU-ME' e 'E A BANDEIRA', sem texto por extenso.

### 208 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0f68c0d651935019-pair.jpg)

- letra: HTML contém ruído 'Chrono Contes1Ina', 'SASALADO BANQUETT' e tabela numérica no lugar da letra.
- cifra: Cifras substituídas por letras/números de OCR; La-/Re-/Mi não preservados de forma utilizável.
- alinhamento: Tabela de coordenadas invade corpo do canto.
- repeticao: Não reproduz os refrães nem as respostas repetidas.

### 209 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9f81fc3b4c530579-pair.jpg)

- letra: Quase toda letra ausente: HTML só apresenta fragmento vermelho 'my eyQtd os (ame'.
- cifra: Sequência harmônica ausente.
- alinhamento: Corpo quase todo vazio.
- repeticao: Todas as repetições do canto ausentes.

### 210 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-768x768.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e96e0f3c5dd4058c-pair.jpg)

- letra: 'demirra', 'émeu', 'Suamão' e 'meu amado entreosjovens' têm fusões.
- cifra: La- de 'A sua sombra' transcrito La, perdendo menor.
- repeticao: BIS A. e barras continuam em vez de expansão das duas respostas.

### 211 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-830x830.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bc060756d22be58a-pair.jpg)

- letra: 'Asuasombra', 'estousentada', 'esquerdaestásobreminhacabeça' fundem palavras.
- alinhamento: Fa de 'COMO ÉS BELA' fica separado verticalmente da letra pela colisão das colunas.
- repeticao: BIS A. ainda indicado nas respostas em vez de repetição por extenso.

### 212 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4eabc508e479e640-pair.jpg)

- letra: Título interno vira 'COMO LINO ENTRE OSEsPINMAS'; letra substituída por 'sate mat eteee', '=Raven conan...' e fragmentos.
- cifra: Cifras da ficha ausentes.
- alinhamento: Grande área vazia em vez das estrofes.
- repeticao: Refrães e BIS sem reprodução.

### 213 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0d4b2d46543b59c8-pair.jpg)

- letra: 'POMBAS SÃO TEUS OLHOS' vira 'POMBAS BAD TEUSOLHOS'; 'NA SALA DO BANQUETE' vira 'HA SALADO GAMQUETE'.
- cifra: La-/Re-/Mi viram sinais como 'ta', 'mm', 'ae'; sequência inutilizável.
- alinhamento: Tabela numérica vermelha ocupa parte central inferior.
- repeticao: Respostas repetidas corrompidas e sem expansão.

### 214 — Como lírio entre espinhos

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-24-15-15-40-480x480.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f8b83040506a8d7e-pair.jpg)

- letra: 'Como perfume de mirra' vira 'Como pertume de mira'; 'Como lírio' vira 'Camp lino'; 'repousa sobre meu peito' vira 'repousa sobes meu paro'.
- cifra: La- e Re- perdem menor; Mi sobre 'peito' vira La; Mi sobre 'LEITO' vira Lab.
- repeticao: BISA permanece na primeira resposta e segunda marca vira ruído 'a gic'.

### 215 — Como Lírio Entre Os Espinhos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/como-lirio-entre-os-espinhos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/80ec796084687e87-pair.jpg)

- letra: 'perfumedemirraé', 'ansiavaestousentada', 'esquerdaestásobreminhacabeça' fundem palavras.
- alinhamento: 'que' deslocado para linha isolada entre 'sombra' e sua continuação.
- repeticao: BIS A. preservado sem expansão nas duas respostas.

### 216 — Formosa és, amiga minha

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/formosa-es-amiga-minha.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fd1ac39a2770e3ee-pair.jpg)

- letra: 'As curvas dos' vira 'As curvasdos'; 'fulgurante como' vira 'fulgurantecomo'; 'torre de' vira 'torrede'.
- cifra: La7 recorrente vira La? em Jerusalém, filha de príncipe, obra de mãos e demais versos.
- alinhamento: La? de 'obra de mãos' separado da frase por grande espaço vertical.
- repeticao: BIS A. vira PISA.; retornos FORMOSA ÉS permanecem em reticências.

### 217 — Onde Te Escondeste, Amado

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/onde-te-escondeste-amado.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/94f7c6b4859eec03-pair.jpg)

- letra: 'te escondeste' vira 'teescondeste'; 'cervo fugiste' vira 'cervofugiste'; 'plantados pela mão' vira 'plantados pelamão'.
- cifra: Mi e Fa7 13 se fundem em 'MiFa713' em passagens; não preserva separação inequívoca dos acordes.
- alinhamento: Mi antes de 'Ó bosques' separado verticalmente; diagrama final Fa7 13 perdido e sobra apenas 'Fa713'.
- repeticao: Retorno MIL GRAÇAS DERRAMANDO permanece abreviado.

### 218 — Roubaste o meu coração

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/roubaste-o-meu-coracao.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0a99da568299cd5c-pair.jpg)

- letra: Último 'ROUBASTE O MEU CORAÇÃO' da abertura omitido: fica só ponto sob Re-. 'ó amados' vira '6 amados'.
- alinhamento: Re- da linha omitida permanece suspenso; La antes de 'Ó AMADOS' muito distante da letra.
- repeticao: BIS A. conservado; retorno final em reticências.

### 219 — Suba O Esposo Ao Lenho Do Seu Tálamo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/suba-o-esposo-ao-lenho-do-seu-talamo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/23e40fcd8666a539-pair.jpg)

- letra: 'e saia a Igreja virgem' vira 'e saiaaIgrejavirgem'; 'Ferido no seu lado logo saiu' vira 'Feridono seu ladologosaiu'.
- repeticao: BIS A. mantido; ambos retornos 'SUBA O ESPOSO,...' não expandidos.

### 220 — Aclamação Ao Evangelho I

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aclamacao-ao-evangelho-i.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/848fefc7af92c6eb-pair.jpg)

- Modelo I: «Eu sou» virou «Eusou»; no Modelo III «esse dará» aparece «essedará» e cifra Mi- antes de «fruto» perdeu posição relativa. Cabeçalhos/modelos fundidos; mantém os três modelos e duas linhas de aleluia.

### 221 — Aclamação Ao Evangelho Ii

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aclamacao-ao-evangelho-ii.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/40eaf6fb0bd48ca4-pair.jpg)

- Modelo II: «Glória ao Senhor» virou «Glóriaao Senhor», «No esplendor» virou «No esplendor da nuvem» sem separação em «esplendor»? Evidência clara: «Este é meu» virou «Este émeu» e «este émeu». Modelo I «eterna glória» virou «eternaglória». Cifras finais Sol/Do da retomada afastadas da letra por linhas vazias.

### 222 — Aclamações Às Orações Dos Fiéis

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aclamacoes-as-oracoes-dos-fieis.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a9d28370d63b9873-pair.jpg)

- Modelo I «Nós vos pedimos, Senhor» virou «Nós vospedimos,Senhor». Modelo III cifras Re Sol e Mi- Si7 Mi- coladas em «ReSol», «Mi-Si7Mi-», prejudicando leitura dos acordes. Mesma melodia do Modelo I fundida em «melodiado Modelo|».

### 223 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/56d7b2b090016281-pair.jpg)

- Modo I «esse dará fruto abundante» virou «esse daráfrutoabundante»; Modo III «Eu sou» virou «Eusou», «e eu nele» virou «e eunele». Linhas de cifras Re/Mi- separadas da letra por vazios; cabeçalho Modo III reconhecido como «Ill». Oito alternativas Aleluia Interlecional serão registradas individualmente.

### 224 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1d1c24f516d65e8b-pair.jpg)

- Alternativa de baixa resolução da mesma ficha. HTML contém linhas numéricas de dados OCR («4 1 1 ... 91.843369»), letra ilegível/inventada («MENU ALELUAA»); cifras não reconstruídas. Revisão integral de transcrição não exaurida: descarte deste rascunho e use fonte maior.

### 225 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4b8886d001e3b9af-pair.jpg)

- Alternativa de resolução ainda menor da mesma ficha. HTML mostra somente título, sem os três modos, letra, cifras ou repetições. Fonte desfocada; não permite validar transcrição.

### 226 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-768x767.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/830d9e4a5610ec8c-pair.jpg)

- Alternativa da mesma ficha: no Modo III a cifra Mi- de «ramos» virou «Mk»; «Eu sou a videira» virou «Eu soua videira». «esse dará fruto abundante» fundido nos três modos. Vazios excessivos separam cifras das linhas.

### 227 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-830x829.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/22191c8bb3aaa394-pair.jpg)

- Alternativa da mesma ficha. Uma tabela extensa de dados OCR aparece entre verso e cifras; parte da letra verticalizada à direita. Após «Eu sou a videira» o fluxo de versos e cifras foi destruído. Revisão integral de transcrição não exaurida diante da corrupção estrutural.

### 228 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7cb484c65b968246-pair.jpg)

- Alternativa de baixa resolução da mesma ficha. HTML reduzido a fragmentos «Momo1», «ma atra Mc AutLDA», «e man aont»; desaparecem modelos, letra reconhecível, cifras e repetições. Transcrição não exaurida, rascunho inutilizável.

### 229 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1e06c24731ff5565-pair.jpg)

- Alternativa da mesma ficha. «ALELUIA» virou «MELINA», «ALELIUM» etc.; Sol/Do/Re/Mi- viraram «sa», «tom», «ta», «w». Verso «Eu sou a videira» irreconhecível. Corrupção generalizada; revisão de transcrição não exaurida.

### 230 — Aleluia Interlecional

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-09-52-480x479.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/00b27de172088f90-pair.jpg)

- Alternativa da mesma ficha. Sol inicial virou «so» e Sol final «5a»; «Eu sou a videira» virou «Eusau andeira». Modo II substituído parcialmente por tabela numérica OCR, versos verticalizados; cifras desconectadas. Transcrição não exaurida.

### 231 — Aleluia Pascal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aleluia-pascal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6eb2d29c07abef66-pair.jpg)

- Sequência S/A1/A2/A3 e três blocos/repetições preservados visualmente, cifras La/Mi/La equivalentes e alinhadas aos três aleluias. Subtítulo «Para o tempo Pascal» fundido como «Parao tempoPascal»; em múltiplas linhas falta espaço após vírgula («ALELUIA,ALELUIA»). Nota das três vozes presente. Corrigir espaços antes de incorporar.

### 232 — Aleluia Pascal II

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/aleluia-pascal-ii.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3e1dce9b6f944b54-pair.jpg)

- «Cristo Jesus» fundido «CristoJesus», «é o Senhor» como «éo Senhor»; coluna direita «Este é o dia que» virou «Este éo diaque» e «fez para» «fezpara». Cifras La/Mi/La e cinco respostas por coluna preservadas; notas presentes, mas marcador ** virou +.

### 233 — Amém, amém, amém

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/amem-amem-amem.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/31136d1d2e4664ae-pair.jpg)

- Cifra Sol7 acima de SABEDORIA e ESTes SÃO virou «Sol?»; «AMÉM» nas retomadas virou «AMEN». «E de onde vêm» fundido «edeondevêm»; «ESTES SÃO OS QUE VÊM» virou «ESTESSÃO OS QUEVEM». Bis ainda literal no rascunho normal. Alinhamento e acentos exigem correção.

### 234 — Anáfora do Sal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/anafora-do-sal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/49f5f9b64b506878-pair.jpg)

- Muitas palavras fundidas: «esteja convosco» virou «estejaconvosco», «justo e necessário» «justoe necessário», «verdadeiro sabor a toda realidade criada» «verdadeirosabor atoda realidadecriada». Cifras deslocadas verticalmente por grandes espaços; blocos BIS A presentes, sem expansão conferida. «e reina pelos séculos» fundido «reinapelosséculos».

### 235 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/75876ad9facf9532-pair.jpg)

- Modo I «ó Cristo» virou «6 Cristo» na primeira resposta; «de eterna» «deeterna», «a videira» «avideira». Modo II cifras Mi- do «No esplendor» e da última linha «escutai-o» perderam menor e renderizam Mi. «filho amado» fundido «filhoamado». Retomadas e dois modos presentes.

### 236 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/22fe38293bdef012-pair.jpg)

- Alternativa de baixa resolução de 235. «GLÓRIA A VÓS, Ó CRISTO» virou «CLOMMAVOS.ODNFTO»; cifras em sua maioria viraram sílabas «tes», «ser», «Wu». Dois modos ainda posicionados, mas letra e harmonia inutilizáveis. Transcrição integral não exaurida.

### 237 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d33317e3f4333840-pair.jpg)

- Alternativa de resolução muito baixa de 235. Corpo sumiu quase completamente: apenas «entire meeerues testaram» em vermelho sob título. Não há versos/cifras/repetições utilizáveis.

### 238 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-768x765.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3ddae08eed8c70c6-pair.jpg)

- Alternativa de 235. «ó Cristo» reconhecido «6 Cristo»; Mi- inicial de «No esplendor» virou Mi maior. «a videira, e vós» virou «avideira,evós» e «ouviu-se a voz do Pai» «ouviu-sea vozdo Pai». Os dois modos/retomadas estão presentes, letra e cifras precisam correção.

### 239 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-830x827.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/293c017c8004a022-pair.jpg)

- Alternativa de 235. Mi- final da primeira linha «Eu sou ... ramos» virou Mi maior. «ó Cristo» virou «6 Cristo»; «Glória ao Senhor» fundido «GlóriaaoSenhor» e «ouviu-se a voz» «ouviu-seavoz». Dois modos e retomadas preservados, alinhamento fica prejudicado pelas fusões.

### 240 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-230x229.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b8f662e49a362c3b-pair.jpg)

- Alternativa de baixa resolução de 235. Restam somente fragmentos «Moto!», «me veta sans», «Magoa», «Amero» sob título. Ausentes versos, cifras e repetições dos dois modos.

### 241 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-350x349.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/eedeb4769f1a7021-pair.jpg)

- Alternativa de 235. «Rei de eterna glória» virou «Re do toraquina»; Sol/Do/Re viraram «sa/bo/ne». Texto do verso e respostas quase inteiramente corrompido. Dois blocos espaciais persistem, mas não a transcrição. Revisão de transcrição não exaurida.

### 242 — Antífona – Versículo antes do Evangelho

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-14-53-480x478.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7cfa3e468ecf4a54-pair.jpg)

- Alternativa de 235. «Glória a vós» virou «Glong avos» e «Eu sou a videira» «Eu soua ydera»; cifras Sol viram «So!», «Sal», Mi- perde menor ou vira «Mr/Mo./Mie». Respostas de ambos modos ainda reconhecíveis, mas incorretas. Transcrição não exaurida.

### 243 — Arpejos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/arpejos.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a525e28fed6abc5f-pair.jpg)

- Ficha técnica de arpejos, sem canto novo. Diagramas de cordas/notas foram perdidos e substituídos por letras «e», «o», «0» dispersas; nota 4ª,5ª,6ª/3ª/2ª/1ª virou 42,52,62/32/22/12. Não serve como representação musical. Precisa preservar imagem/diagramas, não OCR de letra.

### 244 — Benção da Água

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bencao-da-agua-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/eb65c28aa7a5c1d0-pair.jpg)

- Página 1 da Bênção da Água, continuação em 245. «por meio» virou «pormeio», «sinais sacramentais» «sinaissacramentais», «sinal do fim do pecado» «sinaldo fimdo pecado», «foi ungido ... Espírito Santo» «foiungido ... EspíritoSanto». Asteriscos de melisma junto a trechos desapareceram; sobra nota solta. Cifras principais Mi-/La-/Si7/Do/Re presentes, mas vazios separam algumas linhas.

### 245 — Benção da Água

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/bencao-da-agua-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c98df0562a12b38d-pair.jpg)

- Página 2/continuação de 244. «Infundi nesta água» virou «Infundinesta água», «fazei brotar para» «fazeibrotarpara», «sejam sepultados com» «sejam sepultadoscom». «Desça, ó Pai» virou «Desça, 6 Pai» e AMÉM final perdeu acentos. Cifras finais Mi-/Re/Mi- afastadas da letra por linha de pontos; BIS A permanece literal no rascunho normal.

### 246 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c191f182200eff46-pair.jpg)

- «É NOSSO DEVER E SALVAÇÃO» primeira resposta perdeu acento e espaço («E NOSSO DEVER ESALVAÇÃO»); «criastes o homem» virou «criastesohomem», «cheio de» «cheiode», «o Espírito Santo» «oEspíritoSanto». Marcadores P. viram PR em várias entradas. Cifras Sol/La-/Fa/Mi e retomada Santo presentes, mas versos/cifras muito separados.

### 247 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/204b50d667692545-pair.jpg)

- Alternativa de baixa resolução de 246. «ELE ESTÁ NO MEIO DE NÓS» virou «ELEEDTA woMOO TeHOS»; letra generalizadamente corrompida, cifras praticamente ausentes, linha numérica OCR incluída («5 1 ...19.329224»). Revisão integral de transcrição não exaurida.

### 248 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/299026c04612d351-pair.jpg)

- Alternativa desfocada de 246. Corpo ausente: somente «weesrue,» em vermelho sob título. Nenhuma cifra, verso ou resposta preservado.

### 249 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-768x768.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bec7cfe8e1533ccc-pair.jpg)

- Alternativa de 246. «É NOSSO» fundido «ÉNOSSO», «criastes o» «criasteso», «Não o abandonais» «Não oabandonais», «Enviastes ao mundo» «Enviastes aomundo»/fundido. Na coluna direita «para que nos tornássemos» tem leitura visual reordenada: nos tornássemos acima de para que. Cifras mantêm alturas, mas ordem/espaçamento dos versos falham.

### 250 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-830x830.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4f337d4d4e42c717-pair.jpg)

- Alternativa de 246. «nos tornássemos» vira «nostomássemos»; «amor paterno» «amor patemo», instrução «litúrgico» «lúrgico». «O NOSSO CORAÇÃO ESTÁ» perdeu acento em ESTÁ. Vários trechos fundidos («echeio», «demodo», «maisadmiravelmente», «Senhornosso»); cifras ainda presentes. PR/Pp/R substituem marcadores P.

### 251 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/3b4b929802dded17-pair.jpg)

- Alternativa de baixa resolução de 246. OCR só produz fragmentos «+yaaa coms tora vm CON», «tease temer», «cam rat atene», sem o conteúdo litúrgico nem cifras reconhecíveis. Revisão de transcrição não exaurida; fonte insuficiente.

### 252 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1fb9e53ba64d99e8-pair.jpg)

- Alternativa de baixa resolução de 246. «ELE ESTÁ NO MEIO DE NÓS» virou «BLEESTA HO MEIOOE NOS»; Sol/La-/Fa/Mi substituídos por letras isoladas e sílabas. «Não o abandonais» e oração restante irreconhecíveis. Repetição do dever ainda em dois blocos, mas transcrição geral não exaurida.

### 253 — Benção Penitencial

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-17-18-480x480.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/fb760c21151d5b53-pair.jpg)

- Alternativa de 246. Cifras Sol viram «Su/Sa/Sal», La- perde menor como La, Re- vira Re, Fa vira «ta»; «vos bendizemos Senhor» «vosbendgemos Senhar», «ressurreição» «SUAFESBUITOÇÃO». Erros extensos de letra e harmonia; não se confunde com conversão intencional de nomes. Transcrição não exaurida.

### 254 — Celebração Penitencial

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/celebracao-penitencial.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0b1e727ae8c46155-pair.jpg)

- Texto litúrgico próximo de 246 mas título/ficha Celebração Penitencial e resposta «É NOSSO DEVER E NOSSA SALVAÇÃO» em dobro. HTML conserva ambos blocos, porém «criastes o homem» «criasteso homem», «o pecado» «o pecade», «e mais ... o restaurastes» «... orestaurastes», «Não o abandonais» «Não oabandonais». Marcador P. virou [=) numa entrada; cifras muito afastadas verticalmente.

### 255 — Cordeiro de Deus

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/cordeiro-de-deus.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f90eefc50285d5bb-pair.jpg)

- Latim: «QUI TOLLIS» virou «QUITOLLIS» nas três estrofes. Português: «O PECADO» fundido «OPECADO», «DE NÓS» virou «DENOS» sem acento nas duas respostas. Três estrofes, duas frases finais Dona nobis/Dai-nos e cifras La-/Sol/La-/Fa/Mi presentes e equivalentes.

### 256 — Credo

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/credo.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6a80cd03db403f5d-pair.jpg)

- «CREIO EM» virou «CREIOEM», «PAI TODO» «PAITODO», «FOI CONCEBIDO» «FOICONCEBIDO», «PELO PODER» «PELOPODER», «ESTÁ SENTADO À DIREITA DE» «ESTÁSENTADO ÀDIREITADE». Cifras Re-/Fa aparecem coladas «Re-Fa»; Sib/La conservam acidente bemol e alturas, mas alinhamento muda pelas fusões. Ordem do credo até AMÉM e nota final presentes.

### 257 — Glória a Deus no alto do céu

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/gloria-a-deus-no-alto-do-ceu.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/763be5b27e10610f-pair.jpg)

- Letra: «GRAÇAS» virou «GRAGAS»; «SÓ VÓS» perdeu acentos «SO VOS» nas três linhas, AMÉM virou AMEM; «acolhei a nossa súplica» fundido «acolheianossasúplica». Cifras Fa#- e Mi- preservadas visualmente, respostas em ordem, mas espaços e acentos impedem aprovação.

### 258 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/70eecf449e7010ef-pair.jpg)

- «É este o jubileu» fundido «Éesteo jubileu»; «dos antigos profetas» «dos antigosprofetas», «toca as línguas e» «toca as línguase», «Enviai sobre» «Enviai sobre» fundido como «Enviaisobre», «o dom» «odom», «revelai-nos o mistério» «revelai-nosomistério». Quatro retomadas e AMÉM presentes; La-/Sol equivalentes, com deslocamentos pelas palavras fundidas.

### 259 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e28ca091899c7423-pair.jpg)

- Alternativa de baixa resolução de 258. «DIA DE IMENSA ALEGRIA» virou «DADEIMENSA LEONA»; demais estrofes e cifras em fragmentos/sílabas sem sentido. Não conserva letra ou harmonia utilizável. Revisão integral de transcrição não exaurida.

### 260 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c45e8805135b073f-pair.jpg)

- Alternativa muito desfocada de 258. Corpo ausente: somente «maias atestePEMA IS,» sob título. Estrofes, refrões, AMÉM e cifras não foram reconstruídos.

### 261 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-768x767.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/8db6f76e39b4ff3f-pair.jpg)

- Alternativa de 258. La- sobre «dos antigos profetas» perdeu menor e virou La; La- sobre «revelai-nos» aparece «la.» (ponto). Sol La- do AMÉM colados «SolLa-». «mística inebriante» fundida «místic a inebriante»/«místicainebriante»; «resgata os escravos» «resgataos escravos» e deslocado acima do «que». Quatro retomadas preservadas.

### 262 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-830x829.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e5334d90016b9ba0-pair.jpg)

- Alternativa de 258. La- inicial de «Renova-se», em «do ano quinquagésimo», «o dom ... Espírito» e «revelai-nos» perdeu menor e aparece La/La. «mística inebriante» fundida «místicainebriante»; «fonte de eterno» virou «fontede etemo». Linhas «que resgata» e «que acolhe» quebradas com «que» abaixo do restante, ordem visual incorreta.

### 263 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/63e8d8f6850d2dee-pair.jpg)

- Alternativa muito desfocada de 258. Só fragmentos «manucaciotro», «Voa», «comerce», «+ mace tarte» permanecem; letra, cifras e repetições ausentes. Revisão de transcrição não exaurida.

### 264 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e38022518b42ee23-pair.jpg)

- Alternativa de baixa resolução de 258. Refrão «DIA DE IMENSA ALEGRIA» virou «ONADE IMENSAALEGRA»; cifras La-/Sol viram «ta/sa/be/Le» etc.; estrofes ilegíveis. As duas colunas permanecem sem conteúdo musical utilizável. Revisão integral não exaurida.

### 265 — Hino das Laudes de Pentecostes

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-20-05-480x479.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4a49db196149150d-pair.jpg)

- Alternativa de 258. La- perde menor em diversas entradas (La, la, Ls, ts), Sol vira So/Sa/Sal; «Renova-se o prodígio» virou «Renava-s2 oprodigia», «da Igreja nascente» «da lgrgranascente», «que resgata» «Que reagata». «o dom do vosso Espírito» «odom dovossa Espinio». Erros de harmonia, letra e alinhamento; transcrição não exaurida.

### 266 — Ladainha de todos os Santos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ladainha-de-todos-os-santos-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/046e1b7fa831d7a0-pair.jpg)

- Página 1 da Ladainha, continua em267. «São João» perdeu til/acentos e virou «São Joao»; «São Felipe e São Bartolomeu» foi reordenado em «Sao ... Sao Bartolomeu, Felipee» em linha inferior. São João e São Tiago/Santo Estêvão e São Lourenço/São Francisco e São Domingos quebrados com o «e» abaixo dos nomes. Cifras Re Mi- coladas ReMi-. Aspas de repetição viram letras s/pontos e vários NÓS viram NOS.

### 267 — Ladainha de todos os Santos

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ladainha-de-todos-os-santos-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/022510ed0de75f52-pair.jpg)

- Página 2 da Ladainha. «Santa Teresa D’Ávila e» fundido «Santa TeresaD’Ávilae», «Teresinha do» «Teresinhado»; «todos os santos e santas de» «Todos os santose santasde». Linhas Para que nos livreis de todo o mal/pecado foram divididas e reordenadas. «Pela vossa encarnação» e «Por vossa morte e ressurreição» fragmentados. «Christe, audi nos» «Christe,audinos». Alturas Do/Mi-/Sol/Re presentes, mas repetição por aspas e alinhamento não confiáveis.

### 268 — Ladainha Penitencial I

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ladainha-penitencial-i.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6bdcf0d5ec28fdbc-pair.jpg)

- letra: 'vista ao' vira 'vistaao'; 'tivestes piedade' vira 'tivestespiedade'; 'que sois o único' vira 'que soiso único'.
- repeticao: Respostas 'TENDE PIEDADE DE MIM,...' continuam abreviadas, omitindo 'QUE SOU PECADOR' em cada retorno.

### 269 — Ladainha Penitencial II

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/ladainha-penitencial-ii.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ae533ceca1753212-pair.jpg)

- letra: 'Pelos pecados' vira 'Pelospecados'; 'por meio da' vira 'por meioda'; 'nossos pais e' vira 'nossospaise'.
- alinhamento: Reticências em linhas próprias separam respostas das invocações.
- repeticao: 'Pelos pecados que cometemos...' e 'TENDE PIEDADE DE MIM...' permanecem abreviados em todos os grupos.

### 270 — Oração Eucarística II

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-ii-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e4de9a053106da9f-pair.jpg)

- letra: 'esteja convosco' vira 'estejaconvosco'; 'Na verdade, ó Pai' vira 'Naverdade, 6Pai'; 'vós sois santo' vira 'vós soissanto'.
- alinhamento: Marcador P. vira Pp em múltiplas falas; cifras e texto da resposta 'É NOSSO DEVER' separados por grandes vazios.
- repeticao: BIS A. de MORRENDO permanece sem expansão.

### 271 — Oração Eucarística II

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-ii-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ca94230dda696fe5-pair.jpg)

- letra: 'para ser' vira 'paraser'; 'livremente a paixão' vira 'livrementea paixão'; 'ó Pai' vira '6 Pai'; 'por vós' vira 'porvós'.
- alinhamento: La7 sobre 'Tomai, todos, e bebei' separado da frase por enorme intervalo.

### 272 — Oração Eucarística II

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-ii-3.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0ee8b0856319c6ec-pair.jpg)

- letra: 'pelo Espírito Santo' vira 'peloEspíritoSanto'; 'ó Pai' vira '6 Pai'; 'com o nosso' vira 'comonosso'; 'e todos' vira 'etodos'.
- alinhamento: Marcadores N. do papa e bispo ficam acima da linha; ruído 'SE' surge antes da nota de rodapé.

### 273 — Oração Eucarística IV

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-iv-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/49a02dbc7f9a264b-pair.jpg)

- letra: 'celebramos vosso' vira 'celebramosvosso'; 'Criastes o ser humano' vira 'Criasteso serhumano'; 'em luz inacessível' vira 'em luzinacessível'.
- alinhamento: 'Demos graças ao Senhor, nosso Deus' quebra em duas linhas com ordem visual inadequada: 'Demos Senhor, Deus.' acima de 'graças ao nosso'.

### 274 — Oração Eucarística IV

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-iv-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/531d4471c61cde58-pair.jpg)

- letra: 'oferecestes aliança' vira 'oferecestesaliança'; 'família humana' vira 'famíliahumana'; 'próprio Filho' vira 'próprioFilho'; 'Espírito Santo' vira 'EspíritoSanto'.
- alinhamento: Artigo 'a' de 'e a instruístes' isolado em linha inferior.
- repeticao: BIS de RESSUSCITANDO DOS MORTOS permanece sem texto duplicado.

### 275 — Oração Eucarística IV

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-iv-3.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/02af7b462e366b78-pair.jpg)

- letra: 'seus que' aparece 'seusque'; 'bênção' vira 'abênção'; 'Celebrando, agora, ó Pai' vira 'Celebrando,agora,6 Pai'.
- cifra: Do, La-, Fa, Sol, Re- e Mi estão presentes nos dois painéis; sem troca harmônica inequívoca nesta página.
- alinhamento: BIS perde a barra lateral e aparece isolado no intervalo das duas linhas do refrão; cifras e texto recebem espaçamento vertical irregular.
- repeticao: Indicação BIS sobrevive apenas como palavra; seu alcance gráfico não está preservado.

### 276 — Oração Eucarística IV

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/oracao-eucaristica-iv-4.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b4c727f11d39f4a6-pair.jpg)

- letra: 'pelo Espírito' vira 'peloEspírito'; 'ó Pai de bondade' vira '6 Paide bondade'; marcadores '...N' de Papa/Bispo desaparecem.
- cifra: Mi7 e Re- mantidos; cifra Fa final aparece só sobre o terceiro AMÉM, como na fonte.
- alinhamento: 'na paz do vosso Cristo' é quebrado com 'paz' em linha separada; papéis P/A se afastam das linhas.
- repeticao: Duas ocorrências de PARA O LOUVOR e quatro AMÉM preservadas.

### 277 — Pai Nosso

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/pai-nosso.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9d37c2c5d0bfb44c-pair.jpg)

- letra: 'PERDOAI-NOS AS' vira 'PERDOAI-NOSAS'; 'SEJA FEITA A' vira 'SEJAFEITAA'; numerosas palavras coladas.
- cifra: Re-, Fa, La-, Sol-, La e Sib visualmente presentes e na ordem da ficha.
- alinhamento: Espaços de separação da letra perdidos, comprometendo relação sílaba/cifra; nota editorial perde asterisco.
- repeticao: ABBA, ABBA e sequência única do Pai Nosso mantidas.

### 278 — Precônio Pascal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/preconio-pascal-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/86cec7365d421dc1-pair.jpg)

- letra: 'Braçadeira 3º Traste' vira 'Braçadeira 3º Traste' com numeral aparente semelhante; 'nossos pais do Egito' vira 'nossos paisdo Egito'; 'Esta é a Páscoa' vira 'Esta é aPáscoa'.
- cifra: Mi7 da frase 'Esta é a noite em que foram libertados' vira Mi? (extensão ilegível/incorreta).
- alinhamento: Barras laterais dos BIS A./BIS sumiram; grandes vazios verticais quebram estrofes.
- repeticao: Dois DESTRUIU AS TREVAS preservados, mas alcance dos bis não preservado.

### 279 — Precônio Pascal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/preconio-pascal-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/0d6955e3cc97f961-pair.jpg)

- letra: 'Ó noite maravilhosa' vira 'O noitemaravilhosa' com ')' espúrio; 'Cristo não nos teria resgatado' aparece 'Cristonão nos teriaresgatado'.
- cifra: La-, Sol, Do, Fa, Mi e Mi7 presentes; não há alteração harmônica inequívoca além de posicionamento.
- alinhamento: 'Sem o pecado de Adão' quebra com 'o pecado' isolado abaixo; BIS A perde barra de abrangência.
- repeticao: Ó FELIZ CULPA duas vezes e três AMÉM preservados; bis sem alcance gráfico.

### 280 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/2211c2ba0af1d895-pair.jpg)

- letra: 'P.' vira Si, Li) ou PR em diferentes linhas; 'O mistério pascal' vira 'O mistériopascal'; título interno vira 'PREFACIO DA PASCOA!'.
- cifra: Marcador de celebrante P. foi convertido em falsa cifra Si, causando acorde inexistente no começo; demais La-/Re-/Mi/Fa/Sol precisam revisão após remoção dos falsos acordes.
- alinhamento: BIS A isolado sem barra; texto 'É Ele o verdadeiro Cordeiro' deslocado por lacuna vertical.
- repeticao: Duas linhas É NOSSO DEVER mantidas; alcance do bis de MORRENDO não preservado.

### 281 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-300x264.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/97d76601ffef257f-pair.jpg)

- letra: 'O Senhor esteja convosco' foi substituído por 'E O hentersemacomo'; 'DESTRUIU A NOSSA MORTE' vira 'DESTRUA NORIANGRTE'.
- cifra: Quase todas as cifras desaparecem; não há progressão utilizável.
- alinhamento: Palavras e símbolos espúrios substituem a estrutura de canto.
- repeticao: Segunda É NOSSO DEVER ainda reconhecível; bis e demais repetições não recuperados.

### 282 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-768x676.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/affb8bdac0695c1c-pair.jpg)

- letra: 'ó Pai' vira '6 Pai'; 'Cantar o Santo do Tempo Pascal ou outro' vira sequência 'Cant:oSantoacTempoPasta!auoutro'.
- cifra: Sol vira Soi/So!/Sor; La- vira La; Re- vira Re.; Mi vira M. Há perda de qualidade menor.
- alinhamento: Versos fragmentados em alturas diferentes; cifras deixam de alinhar com palavras.
- repeticao: Duas É NOSSO DEVER reconhecíveis; BIS A sem barra.

### 283 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-830x731.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1047cb546070f24a-pair.jpg)

- letra: 'ó Pai' vira '6 Pai'; instrução Cantar o Santo vira 'Carta! SantodcTempoPascal! ou outro'.
- cifra: La- inicial vira La; Re- vira Re; Sol vira So!/Soi; Mi sobre DEUS vira M. Menores perdidos.
- alinhamento: Trecho 'é nosso dever e salvação' fragmentado; barra do BIS À ausente.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes, bis sem escopo.

### 284 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-230x203.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4acd0cf34415dc43-pair.jpg)

- letra: 'O Senhor esteja convosco' substituído por 'ASam eee correa'; corpo contém texto sem correspondência reconhecível.
- cifra: Cifras da fonte não reaparecem como progressão legível.
- alinhamento: Estrutura de versos irreconhecível e colunas fragmentadas.
- repeticao: Refrões e bis não preservados de modo legível.

### 285 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-350x308.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/cf264330fd87e010-pair.jpg)

- letra: 'O Senhor esteja convosco' vira 'DSenhor esteja comanco'; 'ressurgindo' vira 'RESSUAGINDO'; 'É NOSSO' vira 'ENOSBO'.
- cifra: Cifras quase integralmente perdidas, restando caracteres avulsos sem valor musical verificável.
- alinhamento: Palavras fragmentadas e deslocadas; bis vira sinais '=.'.
- repeticao: SANTO triplo mantido, outros refrões corrompidos.

### 286 — Prefácio da Páscoa I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2024/03/Prefacio-da-Pascoa-I-Novo2-480x423.jpg) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b97d3f809bcaa30e-pair.jpg)

- letra: 'O Senhor' vira 'O Sonhor'; 'tirou' vira 'trou'; 'justo' vira 'epusto'.
- cifra: Fa/Sol/La-/Re-/Mi substituídos por caracteres como a, ne, ta e M; harmonia não utilizável.
- alinhamento: Sílabas soltas em linhas intermediárias; instrução de cantar Santo torna-se fragmentos vermelhos.
- repeticao: Duas É NOSSO DEVER e três SANTO ainda visíveis; BIS A sem barra.

### 287 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9549b017c66d32a9-pair.jpg)

- letra: 'ele virá uma segunda vez' vira 'ele viráuma segunda vez'; 'plano de amor' vira 'planode amor'; títulos e indicação inicial com palavras coladas.
- cifra: Sol/La-/Fa/Mi/Do mantidos nas frases legíveis; sem troca harmônica inequívoca.
- alinhamento: 'Por essa razão, agora e sempre' separa 'e' e 'agora sempre' em alturas diversas; papéis P viram PR.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes.

### 288 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/879e188412c8e4b2-pair.jpg)

- letra: 'ELE ESTÁ NO MEIO DE NÓS' vira 'DLEROTAND MBODE MÓS'; texto direito contém linhas numéricas espúrias.
- cifra: Cifras substituídas por números e letras soltas, progressão perdida.
- alinhamento: Tabela numérica atravessa o painel, versos não correspondem à ficha.
- repeticao: Refrões e SANTO não preservados legivelmente.

### 289 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d174d87c4c0ac475-pair.jpg)

- letra: Todo o corpo vira apenas 'cetraçesoentar'.
- cifra: Todas as cifras ausentes.
- alinhamento: Corpo da ficha omitido.
- repeticao: Todas as estrofes e respostas omitidas.

### 290 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-768x768.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/174fcaf7467efcaa-pair.jpg)

- letra: 'ele veio a primeira vez' vira 'eleveio aprimeira vez'; 'Cantar o Santo do tempo litúrgico correspondente' vira 'CantaroSantodotempo Iturgico carres pondente'.
- cifra: Sol/La-/Fa/Mi/Do presentes sem perda inequívoca de qualidade.
- alinhamento: 'Por essa razão, agora e sempre' disperso por três linhas; marcadores P. viram PR.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes.

### 291 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-830x830.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1344655dbce07d90-pair.jpg)

- letra: 'Pai santo' vira 'Paisanto'; 'ele veio' vira 'eleveio'; 'nosso dever e salvação' com 'ésalvação'.
- cifra: Sol/La-/Fa/Mi/Do presentes na ordem da fonte.
- alinhamento: 'Por essa razão, agora e sempre' quebrado em alturas diversas; P. vira PB/PR.
- repeticao: Respostas repetidas e SANTO triplo presentes.

### 292 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6eda7460bef4da18-pair.jpg)

- letra: Corpo inteiro substituído por poucas linhas como 'Cosa peetme samen'.
- cifra: Todas as cifras ausentes.
- alinhamento: Duas colunas curtas não reproduzem os versos.
- repeticao: Respostas e estrofes omitidas.

### 293 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/58fe76e0f5ea96d7-pair.jpg)

- letra: 'ELE ESTÁ NO MEIO DE NÓS' vira 'BLEESTA MO MEIDDEMOS'; 'SANTO' central vira BANTO.
- cifra: Sol/La- substituídos por See/La/na/tn; não preserva qualidade menor e progressão.
- alinhamento: Caracteres dispersos entre os versos; relação cifra/letra destruída.
- repeticao: Respostas reconhecíveis apenas parcialmente.

### 294 — Prefácio do Advento I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-35-44-480x480.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/73537024692d6c3f-pair.jpg)

- letra: 'Revestido de sua glória' vira 'Revesido de sua gona'; 'O Senhor esteja convosco' vira 'O Senhorestejacomosco'; instrução litúrgica corrompida.
- cifra: La- vira La em várias linhas, Mi vira Ar/At, Sol vira So;/Sal; progressão alterada.
- alinhamento: Relação entre sílabas e cifras comprometida pelas palavras fundidas.
- repeticao: Duas respostas É NOSSO DEVER e SANTO triplo reconhecíveis.

### 295 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/1d7af0bbb81b150a-pair.jpg)

- letra: 'O próprio Senhor nos dá a alegria' vira 'O próprioSenhor nos dáa alegria'; 'nos encontre vigilantes na oração' vira 'nos encontrevigilantesna oração'.
- cifra: Sol/La-/Fa/Mi/Do aparecem na ordem da fonte sem perda inequívoca de qualidade.
- alinhamento: 'Por essa razão, agora e sempre' fragmentado em duas linhas; P. vira PR.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes.

### 296 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/30a31362f6edfd83-pair.jpg)

- letra: 'ELE ESTÁ NO MEIO DE NÓS' vira 'CLERETANO MIODEMOS'; corpo substituído por sílabas sem correspondência.
- cifra: Cifras quase todas ausentes, substituídas por a/x/be/ta.
- alinhamento: Versos e acordes não conservam associação.
- repeticao: Respostas e SANTO não preservados legivelmente.

### 297 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7599226e78103f97-pair.jpg)

- letra: Painel HTML apresenta somente o título; corpo inteiro ausente.
- cifra: Todas as cifras omitidas.
- alinhamento: Área do corpo vazia.
- repeticao: Todas as estrofes e respostas omitidas.

### 298 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-768x767.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9db958eade99f542-pair.jpg)

- letra: 'exceto' na indicação litúrgica vira 'exceio'; 'Pai santo' vira 'Paisanto'; 'os seus' vira 'osseus'.
- cifra: La- inicial de Na verdade vira La (perda de menor); demais Sol/La-/Fa/Mi/Do legíveis.
- alinhamento: 'agora' isolado sob 'de entrarmos ... no mistério'; P. vira PR/Pp.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes.

### 299 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-830x829.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/e4230995ab4c97b9-pair.jpg)

- letra: 'Advento' na instrução vira 'Acento'; intervalo '17 a 24' vira '17 4 24'; 'vigilantes na' vira 'vigilantesna'.
- cifra: Sol/La-/Fa/Mi/Do mantidos nas posições gerais da ficha.
- alinhamento: 'agora' isolado sob o verso 'de entrarmos ... no mistério'; P. vira PR.
- repeticao: Duas É NOSSO DEVER e SANTO triplo presentes.

### 300 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/edc95384108e468d-pair.jpg)

- letra: Corpo substituído por quatro linhas como 'Decal romaçanenta ma tera'.
- cifra: Todas as cifras omitidas.
- alinhamento: Estrutura de versos e colunas não reproduzida.
- repeticao: Todas as respostas omitidas.

### 301 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/ff05104fdd084b84-pair.jpg)

- letra: 'O Senhor esteja convosco' vira 'O Secos nolan encaram'; SANTO inicial vira BANTO.
- cifra: Cifras substituídas por su/u/ee/A/ra, sem progressão utilizável.
- alinhamento: Caracteres avulsos e versos fragmentados.
- repeticao: É NOSSO DEVER e SANTO corrompidos.

### 302 — Prefácio do Advento II

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-36-25-480x479.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/966e84cf4c3bd96f-pair.jpg)

- letra: 'nos encontre vigilantes' vira 'nos encontnav igilantes'; 'Predito' vira 'Prado'; 'Batista' vira 'Bahsta'.
- cifra: Sol vira Sal, La- vira La/la e Mi vira Mr; perda de qualidade menor e nomes incorretos.
- alinhamento: Texto e cifras fundidos; instrução de cantar Santo irreconhecível.
- repeticao: Duas respostas e SANTO triplo reconhecíveis.

### 303 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bac348f7ef442905-pair.jpg)

- letra: 'nova luz da vossa glória brilhou para nós' vira 'nova luzda vossa glóriabrilhoupara nós'; 'os anjos' vira 'osanjos'.
- cifra: Sol sobre 'grandeza' vira Sal; demais La-/Fa/Mi/Do presentes.
- alinhamento: P. vira PR; muitas palavras perdem espaços; cifras permanecem próximas às linhas gerais.
- repeticao: Duas É NOSSO DEVER e SANTO triplo presentes.

### 304 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-300x300.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/b972d0729719c263-pair.jpg)

- letra: 'ELE ESTÁ NO MEIO DE NÓS' vira 'GLEESTAWO DOCE HOG'; 'SANTO' vira 'àtanto,BENTOBent'.
- cifra: Progressão substituída por letras avulsas como u/n/v; cifras perdidas.
- alinhamento: Estrutura de estrofes não reproduzida de maneira utilizável.
- repeticao: Respostas e SANTO corrompidos.

### 305 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-150x150.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/247bacb72b000f88-pair.jpg)

- letra: HTML apresenta apenas título; corpo inteiro ausente.
- cifra: Todas as cifras omitidas.
- alinhamento: Corpo do painel vazio.
- repeticao: Respostas e estrofes omitidas.

### 306 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-768x767.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/c1129e63aa42bdf8-pair.jpg)

- letra: 'Pai santo' vira 'Paisanto'; 'nova luz da vossa glória brilhou para nós' funde palavras; instrução litúrgica vira 'CantaraSantodotempohturgrco corres pondento'.
- cifra: La- no final da primeira É NOSSO DEVER vira La. (perde menor); demais Sol/La-/Fa/Mi/Do legíveis.
- alinhamento: P. vira Pp/PR; espaços da letra perdidos.
- repeticao: Duas respostas e SANTO triplo presentes.

### 307 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-830x829.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/674e2995ebd86ab4-pair.jpg)

- letra: 'Por ele' vira 'Por ete'; 'Corações ao alto' vira 'Corações ao aito'; 'oitava' da indicação litúrgica vira 'Olava'.
- cifra: La- final da primeira É NOSSO DEVER vira la. sem menor; demais cifras principais mantidas.
- alinhamento: P. vira Pp/PR; palavras coladas como 'glóriabrilhoupara'.
- repeticao: Duas respostas e SANTO triplo presentes.

### 308 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-230x230.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/828635eb81e15e59-pair.jpg)

- letra: Todo o corpo é reduzido a linhas sem correspondência como 'creamorm eucação'.
- cifra: Todas as cifras omitidas.
- alinhamento: Estrutura de estrofes ausente.
- repeticao: Respostas e estrofes omitidas.

### 309 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-350x350.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/622a9eeeb3a5e245-pair.jpg)

- letra: 'O Senhor esteja convosco' vira 'O Senterenn coaensce'; 'SANTO' é um dos poucos trechos reconhecíveis.
- cifra: Cifras substituídas por ta/la/Ms/m/Sa e símbolos; progressão não utilizável.
- alinhamento: Versos fragmentados com caracteres soltos.
- repeticao: É NOSSO DEVER corrompido, SANTO triplo reconhecível.

### 310 — Prefácio do Natal do Senhor I

**Reprovado** · [Ficha oficial](https://cn.org.br/portal/wp-content/uploads/2023/10/Screenshot-from-2023-10-23-17-37-15-480x479.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f85491df524ae25b-pair.jpg)

- letra: 'Senhor, Pai santo, Deus eterno e todo-poderoso' vira 'Senhor.Pu santo Dous stornoa todo-poderpsa'; 'visível' vira 'vewe'.
- cifra: Sol vira Sal/Sot, La- vira la/La e Mi vira MM/Ma; harmonia alterada e menores perdidos.
- alinhamento: Instrução litúrgica e palavras dos versos corrompidas; P. vira BR.
- repeticao: Duas É NOSSO DEVER e SANTO triplo reconhecíveis.

### 311 — Prefácio Para O Advento E Natal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/prefacio-para-o-advento-e-natal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/11abef77fcea3352-pair.jpg)

- letra: 'É NOSSO' vira 'ENOSSO' sem acento; 'Pai santo' vira 'Paisanto'; 'Se grande era a nossa culpa' vira 'Se grande eraa nossa culpa'.
- cifra: Sol/La-/Fa/Mi/Do visualmente presentes na ordem da ficha.
- alinhamento: Acentos das respostas separados em pontos em linhas próprias; P. vira Pp; espaços fundidos.
- repeticao: Duas É NOSSO DEVER e três SANTO presentes.

### 312 — Prefácio Para O Tempo Pascal

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/prefacio-para-o-tempo-pascal.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/eedf43af5846b855-pair.jpg)

- letra: 'É Ele' vira 'EEle'; 'imolado' vira 'imoiado'; 'pecado do mundo' vira 'pecadodo mundo'.
- cifra: Sol/La-/Re-/Fa/Mi preservados na ordem geral.
- alinhamento: BIS A sem barra de escopo; lacuna antes de É Ele; P. vira PR.
- repeticao: Duas É NOSSO DEVER presentes; BIS A sem escopo gráfico.

### 313 — Prontuário De Acordes

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/prontuario-de-acordes-1.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/bb128939f0e30c10-pair.jpg)

- letra: Não é canto: prontuário de posições de acordes; HTML substitui diagramas por fragmentos como ROR/BEER/ERES.
- cifra: Nomes de muitos acordes sobrevivem, mas todos os diagramas de digitação foram omitidos.
- alinhamento: Grade de sete colunas de diagramas totalmente perdida; nomes ficam sem a posição correspondente.
- repeticao: Não se aplica: documento didático, não cadastrar como canto.

### 314 — Prontuário De Acordes

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/prontuario-de-acordes-2.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/78afa9993b27c216-pair.jpg)

- letra: Não é canto: segunda página do prontuário; aparecem textos espúrios 'Pedido', 'polo', 'ERR'.
- cifra: La# / Sib inicial perde # no La; Si6 vira si6, mas ausência de todos os diagramas é a falha principal.
- alinhamento: Todas as grades de digitação, inclusive campos vazios, foram omitidas.
- repeticao: Não se aplica: documento didático; não tratar como novo canto.

### 315 — Salmodia para as Orações Universais

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodia-para-as-oracoes-universais.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/aac739fc9c405d15-pair.jpg)

- letra: 'sinal e instrumento da presença' vira 'sinale instrumentoda presença'; 'confiado a seus' vira 'confiadoa seus'; 'Ó SENHOR' vira 'O SENHOR' nas primeiras respostas.
- cifra: Mi-, Re e Sol presentes; sequências Mi- Re Mi- mantidas.
- alinhamento: Parêntese espúrio acima da terceira resposta; asterisco da nota editorial perdido.
- repeticao: Quatro ESCUTAI-NOS, Ó SENHOR reconhecíveis, com perda de acento em três.

### 316 — Salmodia Para O Evangelho

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodia-para-o-evangelho.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6e7332252e6d60d6-pair.jpg)

- letra: 'porém não acolheis o nosso testemunho' vira 'porém não acolheiso nosso testemunho'; 'vida eterna' vira 'vidaeterna'; 'Palavra da salvação' perde 'da'.
- cifra: Mi-, Si7, La-, Sol e Re mantidos; grupos colados como Mi-Si7 dificultam separação.
- alinhamento: Cifras finais dos versos continuam próximas das terminações, mas palavras e cifras coladas comprometem leitura.
- repeticao: Duas GLÓRIA A VÓS, SENHOR presentes.

### 317 — Salmodia Para O Rosário

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodia-para-o-rosario.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/d1965d6b06db4aa5-pair.jpg)

- letra: 'bendita sois vós entre as mulheres' vira 'benditasoisvósentreas mulheres'; 'PRINCÍPIO' vira 'PRINCÍCIO'; 'E SEMPRE' vira 'ESEMPRE'.
- cifra: Mi-, Si7, La-, Sol e Re presentes; Si7Mi- final sem separador.
- alinhamento: Palavras coladas alteram relação das cifras às sílabas; final da Glória muito comprimido.
- repeticao: Ave Maria e Glória presentes, sem omissão de resposta.

### 318 — Salmodia para o Salmo Responsorial

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodia-para-o-salmo-responsorial.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/7a7227ba0d58c46c-pair.jpg)

- letra: 'ó Senhor' vira '6 Senhor' na estrofe; 'terra sedenta e sem' vira 'terrasedenta esem'; Ano A recebe acento À.
- cifra: Mi-, La-, Si7 e Do visualmente mantidos.
- alinhamento: BIS A perde barra lateral; reticências dos refrões descem para linha própria.
- repeticao: Duas retomadas SOIS VÓS presentes; alcance do bis inicial não preservado.

### 319 — Salmodia Vi

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodia-vi.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/9d46afd9e77c8103-pair.jpg)

- letra: 'Cantai ao Senhor' vira 'Cantaiao Senhor'; 'perversos' aparece 'dosperversos'; identificação Sl 8 da salmodia X vira 'SJ E:)'.
- cifra: Do7 nas duas primeiras respostas da salmodia VI vira Do?; demais Mi-/Re-/Sol/La- preservados em grande parte.
- alinhamento: Verso 'toquem harpa e tambor em sua honra' fragmentado em duas alturas; letra de Sl 8 quebrada irregularmente.
- repeticao: Salmodias VI–X e respostas presentes; nota editorial perdeu asterisco.

### 320 — Salmodias Para As Laudes

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/salmodias-para-as-laudes.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/68171aa37fe03049-pair.jpg)

- letra: 'ó Senhor Deus' vira '6SenhorDeus'; 'ao clamor da minha prece' vira 'clambda minha prece'; 'Ó MEU REI' perde acento.
- cifra: Re- inicial da salmodia V vira Re (maior); La7 vira Lar; La da flexa da IV vira 'a'.
- alinhamento: Verso 'vosso nome por todo o universo' disperso em duas linhas; cifras de V sem associação segura à letra.
- repeticao: Salmodias I–V e suas respostas presentes; nota editorial sem asterisco.

### 321 — Santo 1982

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-1982.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/a63a5e42f6790cdc-pair.jpg)

- letra: 'Os céus e a terra' vira 'Os céuseaterra'; 'NO ALTO' vira 'NOALTO'; 'É O' vira 'ÉO'.
- cifra: La-, Sol, Fa, Mi e Re- presentes sem alteração harmônica inequívoca.
- alinhamento: Palavras coladas; reticências finais separadas em linhas próprias.
- repeticao: Dois blocos de quatro HOSANA, duas ocorrências 'em nome do Senhor' e retomadas finais presentes.

### 322 — Santo 1988

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-1988.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/27d72157759673ec-pair.jpg)

- letra: 'Os céus e a terra' vira 'Os céuseaterra'; 'Bendito o que vem' vira 'Benditoo que vem'; 'no alto do' vira 'noaltodo'.
- cifra: La-, Sol, Fa e Mi mantidos, inclusive Santo final Fa/Mi.
- alinhamento: Texto colado reduz clareza da posição das cifras em 'Os céus e a terra'.
- repeticao: Alternância S/A, duas duplas de SANTO e HOSANA antes e depois de Bendito preservadas.

### 323 — Santo Hebraico

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-hebraico.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4d0e5ca8ec912b35-pair.jpg)

- letra: 'Os céus e a terra' vira 'Os céuseaterra'; 'do Senhor' vira 'doSenhor'.
- cifra: Sol- e Re- da primeira estrofe aparecem fundidos como 'Sol-Re-', prejudicando separação.
- alinhamento: 'que' de 'Bendito o que vem' isolado em linha abaixo entre 'o' e 'vem'.
- repeticao: Retornos SANTO É SANTO permanecem em reticências.

### 324 — Santo Palestina 74

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-palestina-74.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/6b99ed0fa6b906eb-pair.jpg)

- letra: 'Os céus e a terra' vira 'Oscéuseaterra'; 'nome do Senhor' vira 'nomedo Senhor'; 'SANTO É O' vira 'SANTO ÉO'.
- cifra: Re- Sol- aparecem fundidos como 'Re-Sol-' na estrofe e Bendito.
- alinhamento: Sol-/La acima de primeiro IAHWEH fica afastado verticalmente da letra.
- repeticao: Resposta final HOSANA, HOSANA,... sem expansão.

### 325 — Santo Palomeras 65

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-palomeras-65.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/4f17564f7604679a-pair.jpg)

- letra: 'proclamam a vossa glória' vira 'proclamamavossaglória'; 'hosana nas alturas' vira 'hosananasalturas'; 'Bendito o que vem' vira 'Benditooquevem'.
- repeticao: Ambos retornos SANTO SANTO SANTO continuam abreviados.

### 326 — Santo Roma 77

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/santo-roma-77.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/91f19f053068e9d7-pair.jpg)

- letra: 'Os céus e a terra' vira 'Oscéuseaterra'; 'proclamam vossa glória' vira 'proclamamvossaglória'; 'do Senhor' vira 'doSenhor'.
- cifra: La-/Sol da entrada Bendito apresentados sem espaço como 'La-Sol'.
- alinhamento: La- de 'proclamam vossa glória' e La-/Sol/La- anteriores à estrofe separados verticalmente da letra.
- repeticao: BIS inicial preservado; três retornos SANTO e HOSANA mantidos em reticências.

### 327 — Tabela Para Transportar

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/tabela-para-transportar.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/92f08c523d7f6e25-pair.jpg)

- letra: Prosa fundida: 'altosou baixospara', 'tessiturado cantore', 'tonalidademaior'. Adições 6ª, 7ª, 7ª aum viram '6º,72,722aum'.
- cifra: Tabela maior: Fa# vira Fait, Fa# final da linha Sol vira Fab; Sol# final da linha La vira Sol. Menor: Sol-/La- da linha Mi- perdem menor; Fa#- da linha Si- vira Fat-.
- alinhamento: Bordas, setas e colunas de tônica desaparecem; mini tabela explicativa vira ruído espalhado acima das tabelas.

### 328 — Te Deum

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/te-deum.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/f00cdabff70099fe-pair.jpg)

- letra: 'toda a terra vos adora' vira 'toda aterravosadora'; 'abriste aos que têm fé o reino dos céus' vira 'abristesaos quetêm fé oreinodos céus'; 'guiai e protegei vossos filhos' vira 'guiaie protegeivossosfilhos'.
- repeticao: Quatro retornos A VÓS CANTAM OS ANJOS continuam em reticências, sem refrão integral.

### 329 — Para ti morada santa

**Reprovado** · [Ficha oficial](https://d1f12s1rtcamoi.cloudfront.net/fichas/para-ti-morada-santa.png) · [Comparação](https://github.com/otaviogrrd/Ressuscitou_Flutter/blob/chore/portal-visual-evidence/docs/revisao/evidencias/130138fbde445d60-pair.jpg)

- letra: Junções inequívocas em selarteu, teusangue, fénos e sótu; na segunda coluna tu vais sempre aparece corrompido como tuvai(s)empre.
- letra: Cabeçalho do autor também perde espaços; rascunho não pode substituir transcrição revisada.
- cifra: La-, Mi, Sol e Fa são visíveis nas duas colunas; não foi constatada troca inequívoca de altura nesta inspeção.
- alinhamento: Dois blocos de colunas preservados, mas o espaçamento da letra difere da ficha e exige conferência de ancoragem após reparar as palavras.
- repeticao: Retornos abreviados do refrão permanecem como na ficha; este rascunho normal não valida nem substitui a variante estendida por extenso.
